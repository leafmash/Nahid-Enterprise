package com.nahid.enterprise

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.nahid.enterprise.data.AppState
import com.nahid.enterprise.data.Cloud
import com.nahid.enterprise.data.LoadStatus
import com.nahid.enterprise.data.Product
import com.nahid.enterprise.data.Record
import com.nahid.enterprise.data.Session
import com.nahid.enterprise.data.Store
import com.nahid.enterprise.data.SyncState
import com.nahid.enterprise.ui.Screen
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class AppViewModel(application: Application) : AndroidViewModel(application) {

    val store = Store(application)
    val cloud = Cloud(application, store)

    val appState: StateFlow<AppState> = store.state
    val syncState: StateFlow<SyncState> = cloud.syncState

    var ready by mutableStateOf(false)
        private set

    var session by mutableStateOf<Session?>(null)
        private set

    var stack by mutableStateOf<List<Screen>>(listOf(Screen.Home))
        private set

    var forward by mutableStateOf(true)
        private set

    private var activeId: String? = UNSET

    private val authListener = FirebaseAuth.AuthStateListener { auth -> onUser(auth.currentUser) }

    init {
        cloud.addAuthListener(authListener)
    }

    private fun onUser(user: FirebaseUser?) {
        val id = user?.uid
        if (id == activeId) return
        activeId = id
        ready = true
        forward = true
        stack = listOf(Screen.Home)
        if (user == null) {
            store.setUser(null)
            session = null
            cloud.refresh()
            return
        }
        store.setUser(id)
        session = Session(user.uid, user.email.orEmpty())
        cloud.refresh()
        viewModelScope.launch {
            val status = cloud.load()
            if (status == LoadStatus.Missing) cloud.saveCloud()
        }
    }

    fun open(screen: Screen) {
        forward = true
        stack = stack + screen
    }

    fun selectTab(screen: Screen) {
        forward = true
        stack = listOf(screen)
    }

    fun resetTo(screen: Screen) {
        forward = false
        stack = listOf(screen)
    }

    fun back(): Boolean {
        if (stack.size <= 1) return false
        forward = false
        stack = stack.dropLast(1)
        return true
    }

    fun saveEntry(rec: Record, index: Int, newProducts: List<Product>) {
        store.saveRecord(rec, index)
        store.upsertProducts(newProducts)
        store.applyRates(rec.products)
        store.addPeople(rec.dues.map { it.name })
        cloud.saveCloud()
    }

    fun deleteRecord(index: Int) {
        store.removeRecord(index)
        cloud.saveCloud()
    }

    fun replaceProducts(list: List<Product>) {
        store.setProducts(list)
        cloud.saveCloud()
    }

    fun upsertProducts(list: List<Product>) {
        store.upsertProducts(list)
        cloud.saveCloud()
    }

    fun replacePeople(list: List<String>) {
        store.setPeople(list)
        cloud.saveCloud()
    }

    override fun onCleared() {
        cloud.removeAuthListener(authListener)
        super.onCleared()
    }

    private companion object {
        const val UNSET = "\u0000unset"
    }
}
