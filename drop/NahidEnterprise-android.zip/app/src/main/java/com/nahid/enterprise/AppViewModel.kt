package com.nahid.enterprise

import android.app.Application
import android.os.SystemClock
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.nahid.enterprise.data.AppState
import com.nahid.enterprise.data.Cloud
import com.nahid.enterprise.data.LoadStatus
import com.nahid.enterprise.data.Product
import com.nahid.enterprise.data.Record
import com.nahid.enterprise.data.SavedPdf
import com.nahid.enterprise.data.Session
import com.nahid.enterprise.data.Export
import com.nahid.enterprise.data.PdfDownload
import com.nahid.enterprise.data.Store
import com.nahid.enterprise.data.SyncState
import com.nahid.enterprise.ui.Screen
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class AppViewModel(application: Application) : AndroidViewModel(application) {

    val store = Store(application)
    val cloud = Cloud(application, store)

    val appState: StateFlow<AppState> = store.state
    val syncState: StateFlow<SyncState> = cloud.syncState

    var ready by mutableStateOf(false)
        private set

    var session by mutableStateOf<Session?>(null)
        private set

    var stack by mutableStateOf<List<Screen>>(listOf(Screen.Home))
        private set

    var forward by mutableStateOf(true)
        private set

    var historyQuery by mutableStateOf("")

    var loading by mutableStateOf(false)
        private set

    var loadingMessage by mutableStateOf("")
        private set

    private var loadingDepth = 0

    private var loadJob: Job? = null

    private val scrollStates = HashMap<String, ScrollState>()
    private val listStates = HashMap<String, LazyListState>()

    fun scrollState(key: String): ScrollState = scrollStates.getOrPut(key) { ScrollState(0) }

    fun listState(key: String): LazyListState = listStates.getOrPut(key) { LazyListState() }

    private var activeId: String? = UNSET

    private val authListener = FirebaseAuth.AuthStateListener { auth -> onUser(auth.currentUser) }

    init {
        cloud.addAuthListener(authListener)
    }

    private fun onUser(user: FirebaseUser?) {
        val id = user?.uid
        if (id == activeId) return
        activeId = id
        scrollStates.clear()
        listStates.clear()
        historyQuery = ""
        ready = true
        forward = true
        stack = listOf(Screen.Home)
        if (user == null) {
            store.setUser(null)
            session = null
            cloud.refresh()
            return
        }
        store.setUser(id)
        session = Session(user.uid, user.email.orEmpty())
        cloud.refresh()
        loadJob = viewModelScope.launch {
            val status = cloud.load()
            if (status == LoadStatus.Missing) cloud.saveCloud()
        }
    }

    private suspend fun <T> withLoading(message: String, minMillis: Long, block: suspend () -> T): T {
        val started = SystemClock.elapsedRealtime()
        loadingDepth += 1
        loadingMessage = message
        loading = true
        try {
            return block()
        } finally {
            val remaining = minMillis - (SystemClock.elapsedRealtime() - started)
            withContext(NonCancellable) {
                if (remaining > 0) delay(remaining)
                loadingDepth -= 1
                if (loadingDepth == 0) loading = false
            }
        }
    }

    fun <T> runLoading(
        message: String,
        minMillis: Long = MIN_LOADING,
        work: suspend () -> T,
        done: (Result<T>) -> Unit = {}
    ) {
        viewModelScope.launch {
            val result = try {
                Result.success(withLoading(message, minMillis, work))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
            done(result)
        }
    }

    suspend fun awaitSession() {
        withTimeoutOrNull(SESSION_WAIT) {
            while (session == null) delay(40)
        }
        if (session != null) loadingMessage = "ডেটা লোড হচ্ছে…"
        loadJob?.join()
    }

    suspend fun exportPdf(rec: Record): SavedPdf? {
        val context = getApplication<Application>()
        val saved = Export.saveToPhone(context, rec) ?: return null
        PdfDownload.announce(context, saved)
        return saved
    }

    fun logout() {
        runLoading("Logout হচ্ছে…", work = {
            withTimeoutOrNull(LOGOUT_SYNC) { cloud.syncPending() }
            cloud.logout()
        })
    }

    fun open(screen: Screen) {
        forward = true
        stack = stack + screen
    }

    fun selectTab(screen: Screen) {
        forward = true
        stack = listOf(screen)
    }

    fun resetTo(screen: Screen) {
        forward = false
        stack = listOf(screen)
    }

    fun back(): Boolean {
        if (stack.size <= 1) return false
        forward = false
        stack = stack.dropLast(1)
        return true
    }

    fun saveEntry(rec: Record, index: Int, newProducts: List<Product>) {
        store.saveRecord(rec, index)
        store.upsertProducts(newProducts)
        store.applyRates(rec.products)
        store.addPeople(rec.dues.map { it.name })
        cloud.saveCloud()
    }

    fun deleteRecord(index: Int) {
        store.removeRecord(index)
        cloud.saveCloud()
    }

    fun replaceProducts(list: List<Product>) {
        store.setProducts(list)
        cloud.saveCloud()
    }

    fun upsertProducts(list: List<Product>) {
        store.upsertProducts(list)
        cloud.saveCloud()
    }

    fun replacePeople(list: List<String>) {
        store.setPeople(list)
        cloud.saveCloud()
    }

    override fun onCleared() {
        cloud.removeAuthListener(authListener)
        super.onCleared()
    }

    private companion object {
        const val UNSET = "\u0000unset"
        const val MIN_LOADING = 450L
        const val SESSION_WAIT = 6_000L
        const val LOGOUT_SYNC = 4_000L
    }
}
