package com.nahid.enterprise.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.text.Collator
import java.util.Locale

class Store(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("nahid_store", Context.MODE_PRIVATE)

    private var uid: String? = null
    private var revision = 0

    private val mutableState = MutableStateFlow(AppState())
    val state: StateFlow<AppState> = mutableState.asStateFlow()

    private fun storageKey(id: String) = "nahid:$id"

    private fun dirtyKey(id: String) = "nahid:$id:dirty"

    fun isDirty(): Boolean {
        val id = uid ?: return false
        return prefs.getBoolean(dirtyKey(id), false)
    }

    fun setDirty(flag: Boolean) {
        val id = uid ?: return
        prefs.edit().putBoolean(dirtyKey(id), flag).apply()
    }

    fun rev(): Int = revision

    private fun persist(markDirty: Boolean) {
        val id = uid ?: return
        val snapshot = mutableState.value
        val body = JSONObject()
            .put("products", Codec.productsToLocal(snapshot.products))
            .put("records", Codec.recordsToArray(snapshot.records))
            .put("people", Codec.stringsToArray(snapshot.people))
        val editor = prefs.edit().putString(storageKey(id), body.toString())
        if (markDirty) {
            editor.putBoolean(dirtyKey(id), true)
            revision += 1
        }
        editor.apply()
    }

    private fun change(markDirty: Boolean = true, transform: (AppState) -> AppState) {
        mutableState.value = transform(mutableState.value)
        persist(markDirty)
    }

    fun setUser(id: String?) {
        uid = id
        var next = AppState()
        if (id != null) {
            val saved = prefs.getString(storageKey(id), null)
            if (!saved.isNullOrBlank()) {
                try {
                    val body = JSONObject(saved)
                    val products = Codec.productsFromLocal(body.optJSONArray("products"))
                    val records = Codec.recordsFromArray(body.optJSONArray("records"))
                    val people = Codec.stringsFromArray(body.optJSONArray("people"))
                    next = AppState(
                        products = if (products.isNotEmpty()) products else seedProducts(),
                        records = records,
                        people = people
                    )
                } catch (e: Exception) {
                    next = AppState()
                }
            }
        }
        mutableState.value = next
    }

    fun knownPeople(): List<String> {
        val current = mutableState.value
        val names = LinkedHashSet<String>(current.people)
        current.records.forEach { rec ->
            rec.dues.forEach { due ->
                val name = due.name.trim()
                if (name.isNotEmpty()) names.add(name)
            }
        }
        val collator = Collator.getInstance(Locale("bn"))
        return names.sortedWith { a, b -> collator.compare(a, b) }
    }

    fun setPeople(list: List<String>) = change { it.copy(people = list) }

    fun addPeople(names: List<String>) {
        val current = mutableState.value.people
        val fresh = names.map { it.trim() }
            .filter { it.isNotEmpty() && !current.contains(it) }
            .distinct()
        if (fresh.isEmpty()) return
        change { it.copy(people = it.people + fresh) }
    }

    fun saveRecord(rec: Record, index: Int) = change { state ->
        val list = state.records.toMutableList()
        if (index >= 0 && index < list.size) list[index] = rec else list.add(rec)
        state.copy(records = list)
    }

    fun removeRecord(index: Int) = change { state ->
        if (index < 0 || index >= state.records.size) {
            state
        } else {
            val list = state.records.toMutableList()
            list.removeAt(index)
            state.copy(records = list)
        }
    }

    fun setProducts(list: List<Product>) = change { it.copy(products = list) }

    fun upsertProducts(list: List<Product>) = change { state ->
        val products = state.products.toMutableList()
        list.forEach { incoming ->
            val at = products.indexOfFirst { it.name == incoming.name }
            if (at >= 0) products[at] = products[at].copy(rate = incoming.rate) else products.add(incoming)
        }
        state.copy(products = products)
    }

    fun applyRates(lines: List<ProductLine>) = change { state ->
        val products = state.products.toMutableList()
        lines.forEach { line ->
            val at = products.indexOfFirst { it.name == line.product }
            if (at >= 0) products[at] = products[at].copy(rate = line.rate)
        }
        state.copy(products = products)
    }

    fun exportCloud(): Map<String, Any> {
        val current = mutableState.value
        return mapOf(
            "products" to Codec.stringsToArray(current.products.map { it.name }).toString(),
            "rates" to Codec.ratesToArray(current.products).toString(),
            "records" to Codec.recordsToArray(current.records).toString(),
            "people" to Codec.stringsToArray(current.people).toString()
        )
    }

    fun importCloud(doc: Map<String, Any?>) {
        val names = Codec.parseArray(doc["products"] as? String)
        val rates = Codec.parseArray(doc["rates"] as? String)
        val records = Codec.parseArray(doc["records"] as? String)
        val people = Codec.parseArray(doc["people"] as? String)
        change(markDirty = false) { state ->
            var products = state.products
            if (names != null) {
                products = List(names.length()) { i ->
                    Product(names.optString(i, ""), rates?.optDouble(i, 0.0)?.takeIf { !it.isNaN() } ?: 0.0)
                }
            }
            if (products.isEmpty()) products = seedProducts()
            state.copy(
                products = products,
                records = if (records != null) Codec.recordsFromArray(records) else state.records,
                people = if (people != null) Codec.stringsFromArray(people) else state.people
            )
        }
    }
}
