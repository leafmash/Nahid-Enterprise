package com.nahid.enterprise.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Palette {
    val Canvas = Color(0xFFF2F5FA)
    val Ink = Color(0xFF0B2A55)
    val Primary = Color(0xFF2456A4)
    val Soft = Color(0xFFE6EEFB)
    val Gold = Color(0xFFF2B72B)
    val OnGold = Color(0xFF2A1D00)
    val Text = Color(0xFF141A24)
    val Muted = Color(0xFF66707F)
    val Line = Color(0xFFE8ECF3)
    val Field = Color(0xFFF2F5FA)
    val Pos = Color(0xFF0B7A52)
    val Neg = Color(0xFFC9382E)
    val Warn = Color(0xFFA15C00)
    val Chevron = Color(0xFFADB5C4)
    val TabIdle = Color(0xFF7D8696)
    val Trash = Color(0xFFA3ABB9)
    val PosBand = Color(0xFFDFF4EA)
    val NegBand = Color(0xFFFDE6E3)
    val OpenBand = Color(0xFFFFF1CF)
    val OpenText = Color(0xFF7A5200)
}

@Composable
fun NahidTheme(content: @Composable () -> Unit) {
    val scheme = lightColorScheme(
        primary = Palette.Ink,
        onPrimary = Color.White,
        primaryContainer = Palette.Soft,
        onPrimaryContainer = Palette.Ink,
        secondary = Palette.Primary,
        onSecondary = Color.White,
        secondaryContainer = Palette.Soft,
        onSecondaryContainer = Palette.Ink,
        tertiary = Palette.Gold,
        onTertiary = Palette.OnGold,
        background = Palette.Canvas,
        onBackground = Palette.Text,
        surface = Color.White,
        onSurface = Palette.Text,
        surfaceVariant = Palette.Field,
        onSurfaceVariant = Palette.Muted,
        outline = Palette.Line,
        outlineVariant = Palette.Line,
        error = Palette.Neg
    )
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
