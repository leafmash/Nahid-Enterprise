package com.nahid.enterprise.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Palette {
    val Canvas = Color(0xFFF3F6FC)
    val Ink = Color(0xFF0B2A55)
    val InkDeep = Color(0xFF071C3B)
    val Primary = Color(0xFF2456A4)
    val PrimaryBright = Color(0xFF3A74D1)
    val Soft = Color(0xFFE4EDFC)
    val Gold = Color(0xFFF2B72B)
    val GoldLight = Color(0xFFFFD36B)
    val OnGold = Color(0xFF2A1D00)
    val Text = Color(0xFF131A26)
    val Muted = Color(0xFF68738A)
    val Line = Color(0xFFE9EDF5)
    val Field = Color(0xFFF4F7FC)
    val Pos = Color(0xFF0B7A52)
    val PosLight = Color(0xFF7CF0BD)
    val Neg = Color(0xFFC9382E)
    val NegLight = Color(0xFFFFA9A1)
    val Warn = Color(0xFFA15C00)
    val Chevron = Color(0xFFB4BCCB)
    val TabIdle = Color(0xFF7D8696)
    val Trash = Color(0xFFB0B8C6)
    val PosBand = Color(0xFFDDF5EA)
    val NegBand = Color(0xFFFDE8E5)
    val OpenBand = Color(0xFFFFF1CF)
    val OpenText = Color(0xFF7A5200)
    val BarIdle = Color(0xFFD4E1F6)
}

object Shapes {
    val Card = RoundedCornerShape(24.dp)
    val Control = RoundedCornerShape(18.dp)
    val Pill = RoundedCornerShape(50)
}

object Brushes {
    val Header = Brush.linearGradient(listOf(Color(0xFF0A2750), Color(0xFF1B4C97), Color(0xFF2A62B8)))
    val Primary = Brush.linearGradient(listOf(Color(0xFF2F68C0), Color(0xFF0E3270)))
    val Gold = Brush.linearGradient(listOf(Color(0xFFFFD36B), Color(0xFFF2B72B)))
    val Bar = Brush.verticalGradient(listOf(Color(0xFF3A74D1), Color(0xFF0B2A55)))
    val BarToday = Brush.verticalGradient(listOf(Color(0xFFFFD36B), Color(0xFFF2B72B)))
}

private fun flat(style: TextStyle): TextStyle = style.copy(letterSpacing = 0.sp)

private fun typography(): Typography {
    val base = Typography()
    return base.copy(
        displayLarge = flat(base.displayLarge),
        displayMedium = flat(base.displayMedium),
        displaySmall = flat(base.displaySmall),
        headlineLarge = flat(base.headlineLarge),
        headlineMedium = flat(base.headlineMedium),
        headlineSmall = flat(base.headlineSmall),
        titleLarge = flat(base.titleLarge),
        titleMedium = flat(base.titleMedium),
        titleSmall = flat(base.titleSmall),
        bodyLarge = flat(base.bodyLarge),
        bodyMedium = flat(base.bodyMedium),
        bodySmall = flat(base.bodySmall),
        labelLarge = flat(base.labelLarge),
        labelMedium = flat(base.labelMedium),
        labelSmall = flat(base.labelSmall)
    )
}

@Composable
fun NahidTheme(content: @Composable () -> Unit) {
    val scheme = lightColorScheme(
        primary = Palette.Ink,
        onPrimary = Color.White,
        primaryContainer = Palette.Soft,
        onPrimaryContainer = Palette.Ink,
        secondary = Palette.Primary,
        onSecondary = Color.White,
        secondaryContainer = Palette.Soft,
        onSecondaryContainer = Palette.Ink,
        tertiary = Palette.Gold,
        onTertiary = Palette.OnGold,
        background = Palette.Canvas,
        onBackground = Palette.Text,
        surface = Color.White,
        onSurface = Palette.Text,
        surfaceVariant = Palette.Field,
        onSurfaceVariant = Palette.Muted,
        outline = Palette.Line,
        outlineVariant = Palette.Line,
        inversePrimary = Palette.GoldLight,
        error = Palette.Neg
    )
    MaterialTheme(colorScheme = scheme, typography = typography(), content = content)
}
