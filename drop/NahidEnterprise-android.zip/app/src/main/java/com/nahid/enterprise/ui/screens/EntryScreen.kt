package com.nahid.enterprise.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nahid.enterprise.AppViewModel
import com.nahid.enterprise.R
import com.nahid.enterprise.data.Due
import com.nahid.enterprise.data.Export
import com.nahid.enterprise.data.Product
import com.nahid.enterprise.data.ProductLine
import com.nahid.enterprise.data.Record
import com.nahid.enterprise.ui.ActionsBox
import com.nahid.enterprise.ui.AppButton
import com.nahid.enterprise.ui.BtnKind
import com.nahid.enterprise.ui.ConfirmDialog
import com.nahid.enterprise.ui.Field
import com.nahid.enterprise.ui.FieldsBox
import com.nahid.enterprise.ui.Glyph
import com.nahid.enterprise.ui.GroupBox
import com.nahid.enterprise.ui.Heading
import com.nahid.enterprise.ui.Hint
import com.nahid.enterprise.ui.Notifier
import com.nahid.enterprise.ui.Page
import com.nahid.enterprise.ui.Palette
import com.nahid.enterprise.ui.Rule
import com.nahid.enterprise.ui.Screen
import com.nahid.enterprise.ui.TrashButton
import com.nahid.enterprise.util.fmt
import com.nahid.enterprise.util.num
import com.nahid.enterprise.util.taka
import com.nahid.enterprise.util.today
import java.util.concurrent.atomic.AtomicLong

private class ItemRow(
    val id: Long,
    val isNew: Boolean,
    product: String,
    qty: String,
    ret: String,
    rate: String
) {
    var product by mutableStateOf(product)
    var qty by mutableStateOf(qty)
    var ret by mutableStateOf(ret)
    var rate by mutableStateOf(rate)
    val focus = FocusRequester()
    var autoFocus = false
}

private class DueRow(
    val id: Long,
    name: String,
    amount: String,
    paid: Boolean
) {
    var name by mutableStateOf(name)
    var amount by mutableStateOf(amount)
    var paid by mutableStateOf(paid)
    val focus = FocusRequester()
    var autoFocus = false
}

private fun netOf(qty: Double, ret: Double, rate: Double): Double = maxOf(0.0, qty - ret) * rate

private fun focusSafely(requester: FocusRequester) {
    try {
        requester.requestFocus()
    } catch (e: Exception) {
        return
    }
}

@Composable
internal fun AddRow(label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 60.dp)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .background(Palette.Soft, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Glyph(R.drawable.ic_plus, Palette.Primary, size = 20.dp)
        }
        Text(label, color = Palette.Primary, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ItemBlock(row: ItemRow, onRemove: () -> Unit) {
    LaunchedEffect(row) {
        if (row.autoFocus) {
            row.autoFocus = false
            focusSafely(row.focus)
        }
    }
    val net = netOf(num(row.qty), num(row.ret), num(row.rate))
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (row.isNew) {
                Field(
                    value = row.product,
                    onValueChange = { row.product = it },
                    label = "নতুন দ্রব্যের নাম",
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(row.focus)
                )
            } else {
                Text(
                    text = row.product,
                    modifier = Modifier.weight(1f),
                    color = Palette.Ink,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Box(
                Modifier
                    .background(Palette.Soft, CircleShape)
                    .padding(horizontal = 14.dp, vertical = 5.dp)
            ) {
                Text(taka(net), color = Palette.Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            TrashButton("এই দ্রব্য বাদ দিন", onRemove)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Field(
                value = row.qty,
                onValueChange = { row.qty = it },
                label = "পরিমাণ",
                modifier = Modifier
                    .weight(1f)
                    .then(if (row.isNew) Modifier else Modifier.focusRequester(row.focus)),
                keyboard = KeyboardType.Decimal
            )
            Field(
                value = row.ret,
                onValueChange = { row.ret = it },
                label = "ফেরত",
                modifier = Modifier.weight(1f),
                keyboard = KeyboardType.Decimal
            )
            Field(
                value = row.rate,
                onValueChange = { row.rate = it },
                label = "দর (৳)",
                modifier = Modifier.weight(1f),
                keyboard = KeyboardType.Decimal
            )
        }
    }
}

@Composable
private fun DueBlock(row: DueRow, known: List<String>, onRemove: () -> Unit) {
    LaunchedEffect(row) {
        if (row.autoFocus) {
            row.autoFocus = false
            focusSafely(row.focus)
        }
    }
    var focused by remember { mutableStateOf(false) }
    val typed = row.name.trim()
    val matches = if (focused) {
        known.filter { it.contains(typed, ignoreCase = true) && !it.equals(typed, ignoreCase = true) }.take(6)
    } else {
        emptyList()
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Field(
                        value = row.name,
                        onValueChange = { row.name = it },
                        label = "ব্যক্তির নাম",
                        modifier = Modifier
                            .weight(1.5f)
                            .onFocusChanged { focused = it.isFocused }
                            .focusRequester(row.focus)
                    )
                    Field(
                        value = row.amount,
                        onValueChange = { row.amount = it },
                        label = "বাকি টাকা (৳)",
                        modifier = Modifier.weight(1f),
                        keyboard = KeyboardType.Decimal
                    )
                }
                if (matches.isNotEmpty()) {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        matches.forEach { person ->
                            Box(
                                Modifier
                                    .background(Palette.Soft, CircleShape)
                                    .clickable { row.name = person }
                                    .padding(horizontal = 14.dp, vertical = 7.dp)
                            ) {
                                Text(person, color = Palette.Primary, fontSize = 14.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
            TrashButton("এই ব্যক্তি বাদ দিন", onRemove)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("PAID — টাকা পেয়েছি", fontWeight = FontWeight.Medium, color = Palette.Ink)
            Switch(
                checked = row.paid,
                onCheckedChange = { row.paid = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Palette.Pos,
                    checkedBorderColor = Color.Transparent,
                    uncheckedThumbColor = Color.White,
                    uncheckedTrackColor = Color(0xFFC9D1DE),
                    uncheckedBorderColor = Color.Transparent
                )
            )
        }
    }
}

@Composable
fun EntryScreen(vm: AppViewModel, notify: Notifier, index: Int, fromIncomplete: Boolean) {
    val sync by vm.syncState.collectAsState()
    val context = LocalContext.current
    val existing = remember(index) {
        if (index >= 0) vm.store.state.value.records.getOrNull(index) else null
    }
    val ids = remember { AtomicLong(0) }

    var name by remember { mutableStateOf(existing?.name ?: "") }
    var dest by remember { mutableStateOf(existing?.dest ?: "") }
    var date by remember { mutableStateOf(existing?.date ?: today()) }
    var comment by remember { mutableStateOf(existing?.comment ?: "") }
    var damage by remember { mutableStateOf(if (existing != null) fmt(existing.damage) else "") }
    var cash by remember { mutableStateOf(if (existing != null) fmt(existing.cash) else "") }
    var saving by remember { mutableStateOf(false) }
    var showLeave by remember { mutableStateOf(false) }

    val items = remember {
        val source = if (existing != null) {
            existing.products.map {
                ItemRow(ids.incrementAndGet(), false, it.product, fmt(it.qty), fmt(it.ret), fmt(it.rate))
            }
        } else {
            vm.store.state.value.products.map {
                ItemRow(ids.incrementAndGet(), false, it.name, "", "", fmt(it.rate))
            }
        }
        mutableStateListOf<ItemRow>().apply { addAll(source) }
    }

    val dues = remember {
        val source = existing?.dues?.takeIf { it.isNotEmpty() } ?: listOf(Due("", 0.0, false))
        val rows = source.map {
            DueRow(ids.incrementAndGet(), it.name, if (it.amount != 0.0) fmt(it.amount) else "", it.paid)
        }
        mutableStateListOf<DueRow>().apply { addAll(rows) }
    }

    val known = remember { vm.store.knownPeople() }

    fun totalNow(): Double = items.sumOf { netOf(num(it.qty), num(it.ret), num(it.rate)) }

    fun finalNow(): Double {
        val due = dues.sumOf { if (it.paid) 0.0 else num(it.amount) }
        return totalNow() - num(damage) - num(cash) - due
    }

    fun snapshot(): String {
        val head = listOf(name, dest, date, comment, damage, cash).joinToString("\u0001")
        val itemPart = items.joinToString("\u0003") { "${it.isNew}|${it.product}|${it.qty}|${it.ret}|${it.rate}" }
        val duePart = dues.joinToString("\u0003") { "${it.name}|${it.amount}|${it.paid}" }
        return head + "\u0002" + itemPart + "\u0002" + duePart
    }

    val initial = remember { snapshot() }

    fun requestBack() {
        if (snapshot() != initial) showLeave = true else vm.back()
    }

    BackHandler(enabled = true) { requestBack() }

    fun removeItem(row: ItemRow) {
        val at = items.indexOf(row)
        if (at < 0) return
        items.removeAt(at)
        val label = row.product.ifBlank { "দ্রব্য" }
        notify.show("$label এই হিসাব থেকে বাদ দেওয়া হয়েছে", "ফিরিয়ে আনুন") {
            items.add(minOf(at, items.size), row)
        }
    }

    fun removeDue(row: DueRow) {
        val at = dues.indexOf(row)
        if (at < 0) return
        dues.removeAt(at)
        val label = row.name.ifBlank { "ব্যক্তি" }
        notify.show("$label বাকির তালিকা থেকে বাদ দেওয়া হয়েছে", "ফিরিয়ে আনুন") {
            dues.add(minOf(at, dues.size), row)
        }
    }

    fun save() {
        if (saving) return
        val kept = items.filter { r ->
            !(r.isNew && r.product.trim().isEmpty() && num(r.qty) == 0.0 && num(r.ret) == 0.0 && num(r.rate) == 0.0)
        }
        val blank = kept.firstOrNull { it.isNew && it.product.trim().isEmpty() }
        if (blank != null) {
            notify.show("নতুন দ্রব্যের নাম লিখুন")
            focusSafely(blank.focus)
            return
        }
        val names = kept.map { it.product.trim().lowercase() }
        val dupAt = names.indices.firstOrNull { names.indexOf(names[it]) != it }
        if (dupAt != null) {
            notify.show("\"${kept[dupAt].product.trim()}\" দুইবার আছে")
            focusSafely(kept[dupAt].focus)
            return
        }
        val dueRows = dues.filter { it.name.trim().isNotEmpty() || num(it.amount) != 0.0 }
        val nameless = dueRows.firstOrNull { it.name.trim().isEmpty() }
        if (nameless != null) {
            notify.show("বাকি ব্যক্তির নাম লিখুন")
            focusSafely(nameless.focus)
            return
        }

        saving = true
        val lines = kept.map { r ->
            val product = if (r.isNew) r.product.trim() else r.product
            val qty = num(r.qty)
            val ret = num(r.ret)
            val rate = num(r.rate)
            ProductLine(product, qty, ret, rate, netOf(qty, ret, rate))
        }
        val dueList = dueRows.map { Due(it.name.trim(), num(it.amount), it.paid) }
        val makeIncomplete = index < 0
        val record = Record(
            name = name,
            dest = dest,
            date = date,
            comment = comment,
            damage = num(damage),
            cash = num(cash),
            incomplete = makeIncomplete,
            products = lines,
            dues = dueList,
            total = totalNow(),
            finalAmount = finalNow()
        )
        val fresh = kept.filter { it.isNew }.map { Product(it.product.trim(), num(it.rate)) }
        vm.saveEntry(record, index, fresh)
        var message = if (makeIncomplete) "অসম্পূর্ণ হিসাব Save হয়েছে" else "হিসাব Save হয়েছে"
        if (!makeIncomplete && Export.saveToPhone(context, record)) {
            message += " — File Downloads-এ রাখা হয়েছে"
        }
        notify.show(message)
        vm.resetTo(Screen.Home)
    }

    val total = totalNow()
    val finalAmount = finalNow()
    val buttonLabel = when {
        index < 0 -> "অসম্পূর্ণ হিসাব হিসেবে Save"
        fromIncomplete -> "সম্পূর্ণ হিসাব সংরক্ষণ"
        else -> "Correction Save"
    }

    Page(
        title = if (index < 0) "নতুন হিসাব" else "হিসাব সংশোধন",
        sync = sync,
        onBack = { requestBack() },
        bottom = {
            Surface(
                color = Color.White,
                shadowElevation = 16.dp,
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 22.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("মোট নিট বিক্রি", color = Palette.Muted, fontSize = 13.sp)
                        Text(taka(total), color = Palette.Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(
                        modifier = Modifier
                            .background(
                                if (finalAmount < 0) Palette.NegBand else Palette.PosBand,
                                RoundedCornerShape(18.dp)
                            )
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            "চূড়ান্ত হিসাব",
                            color = if (finalAmount < 0) Palette.Neg else Palette.Pos,
                            fontSize = 12.sp
                        )
                        Text(
                            taka(finalAmount),
                            color = if (finalAmount < 0) Palette.Neg else Palette.Pos,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    ) {
        FieldsBox {
            Field(value = name, onValueChange = { name = it }, label = "নাম")
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Field(value = dest, onValueChange = { dest = it }, label = "গন্তব্য", modifier = Modifier.weight(1f))
                Field(value = date, onValueChange = { date = it }, label = "তারিখ", modifier = Modifier.weight(1f))
            }
        }

        Heading("দ্রব্যের হিসাব")
        GroupBox {
            items.toList().forEachIndexed { position, row ->
                if (position > 0) Rule()
                key(row.id) { ItemBlock(row) { removeItem(row) } }
            }
            if (items.isNotEmpty()) Rule()
            AddRow("নতুন দ্রব্য ও দর যোগ করুন") {
                val row = ItemRow(ids.incrementAndGet(), true, "", "", "", "")
                row.autoFocus = true
                items.add(row)
            }
        }
        Hint("নতুন দ্রব্য Save করলে দ্রব্যের নাম ও দরের তালিকাতেও যুক্ত হবে। ভুল দ্রব্য বাদ দিতে ডানের ডাস্টবিন চাপুন।")

        Heading("ডেমেজ ও ক্যাশ")
        FieldsBox {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Field(
                    value = damage,
                    onValueChange = { damage = it },
                    label = "ডেমেজ (৳)",
                    modifier = Modifier.weight(1f),
                    keyboard = KeyboardType.Decimal
                )
                Field(
                    value = cash,
                    onValueChange = { cash = it },
                    label = "হ্যান্ড ক্যাশ (৳)",
                    modifier = Modifier.weight(1f),
                    keyboard = KeyboardType.Decimal
                )
            }
        }

        Heading("বাকির হিসাব")
        GroupBox {
            dues.toList().forEachIndexed { position, row ->
                if (position > 0) Rule()
                key(row.id) { DueBlock(row, known) { removeDue(row) } }
            }
            if (dues.isNotEmpty()) Rule()
            AddRow("বাকি ব্যক্তি যোগ করুন") {
                val row = DueRow(ids.incrementAndGet(), "", "", false)
                row.autoFocus = true
                dues.add(row)
            }
        }

        Heading("মন্তব্য")
        FieldsBox {
            Field(value = comment, onValueChange = { comment = it }, label = "মন্তব্য")
        }

        ActionsBox {
            AppButton(buttonLabel, kind = BtnKind.Gold, enabled = !saving) { save() }
        }
    }

    if (showLeave) {
        ConfirmDialog(
            title = "বের হবেন?",
            message = "Save না করা তথ্য মুছে যাবে।",
            ok = "বের হন",
            cancel = "থাকুন",
            danger = true,
            onConfirm = {
                showLeave = false
                vm.back()
            },
            onDismiss = { showLeave = false }
        )
    }
}
