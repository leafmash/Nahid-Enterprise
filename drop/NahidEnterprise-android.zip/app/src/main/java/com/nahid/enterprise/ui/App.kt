package com.nahid.enterprise.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.nahid.enterprise.AppViewModel
import com.nahid.enterprise.R
import com.nahid.enterprise.ui.screens.AccountInfoScreen
import com.nahid.enterprise.ui.screens.AccountScreen
import com.nahid.enterprise.ui.screens.DetailScreen
import com.nahid.enterprise.ui.screens.DuesScreen
import com.nahid.enterprise.ui.screens.EntryScreen
import com.nahid.enterprise.ui.screens.HistoryScreen
import com.nahid.enterprise.ui.screens.HomeScreen
import com.nahid.enterprise.ui.screens.IncompleteScreen
import com.nahid.enterprise.ui.screens.ProductsScreen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class Notifier(private val host: SnackbarHostState, private val scope: CoroutineScope) {

    fun show(message: String) {
        post(message, null, null)
    }

    fun show(message: String, label: String, action: () -> Unit) {
        post(message, label, action)
    }

    private fun post(message: String, label: String?, action: (() -> Unit)?) {
        scope.launch {
            host.currentSnackbarData?.dismiss()
            val result = host.showSnackbar(
                message = message,
                actionLabel = label,
                withDismissAction = false,
                duration = if (label != null) SnackbarDuration.Long else SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) action?.invoke()
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private data class TabItem(val icon: Int, val label: String, val screen: Screen)

private val tabs = listOf(
    TabItem(R.drawable.ic_home, "হোম", Screen.Home),
    TabItem(R.drawable.ic_list, "আগের হিসাব", Screen.History),
    TabItem(R.drawable.ic_users, "বাকি", Screen.Dues),
    TabItem(R.drawable.ic_user, "Account", Screen.AccountInfo)
)

@Composable
private fun TabButton(tab: TabItem, selected: Boolean, onClick: () -> Unit) {
    val background by animateColorAsState(
        targetValue = if (selected) Palette.Soft else Color.Transparent,
        animationSpec = tween(220),
        label = "tabBackground"
    )
    val tint by animateColorAsState(
        targetValue = if (selected) Palette.Ink else Palette.TabIdle,
        animationSpec = tween(220),
        label = "tabTint"
    )
    Row(
        modifier = Modifier
            .height(48.dp)
            .clip(CircleShape)
            .background(background)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                role = Role.Tab,
                onClick = onClick
            )
            .padding(horizontal = 15.dp)
            .animateContentSize(animationSpec = tween(240)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Glyph(tab.icon, tint)
        if (selected) {
            Text(
                text = tab.label,
                modifier = Modifier.padding(start = 8.dp),
                color = Palette.Ink,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun AppTabs(current: Screen, onSelect: (Screen) -> Unit) {
    val haptic = LocalHapticFeedback.current
    Surface(
        modifier = Modifier
            .navigationBarsPadding()
            .padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 12.dp),
        shape = RoundedCornerShape(32.dp),
        color = Color.White,
        shadowElevation = 12.dp,
        border = BorderStroke(1.dp, Palette.Line)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEach { tab ->
                TabButton(tab, tab.screen == current) {
                    if (tab.screen != current) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelect(tab.screen)
                    }
                }
            }
        }
    }
}

@Composable
private fun ScreenHost(screen: Screen, vm: AppViewModel, notify: Notifier) {
    Box(Modifier.fillMaxSize().background(Palette.Canvas)) {
        when (screen) {
            Screen.Home -> HomeScreen(vm)
            Screen.History -> HistoryScreen(vm)
            Screen.Dues -> DuesScreen(vm, notify)
            Screen.AccountInfo -> AccountInfoScreen(vm, notify)
            Screen.Incomplete -> IncompleteScreen(vm)
            Screen.Products -> ProductsScreen(vm, notify)
            is Screen.Entry -> EntryScreen(vm, notify, screen.index, screen.fromIncomplete)
            is Screen.Detail -> DetailScreen(vm, notify, screen.index)
        }
    }
}

@Composable
fun NahidRoot(vm: AppViewModel) {
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val notify = remember { Notifier(snackbar, scope) }

    var minimumShown by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(1600)
        minimumShown = true
    }
    val showSplash = !minimumShown || !vm.ready

    val loggedIn = vm.session != null
    val top = vm.stack.last()
    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    val showBar = loggedIn && isTab(top) && !imeVisible
    val showFab = showBar && (top == Screen.Home || top == Screen.History)

    val view = LocalView.current
    SideEffect {
        val window = view.context.findActivity()?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = showSplash
            controller.isAppearanceLightNavigationBars = true
        }
    }

    BackHandler(enabled = loggedIn && (vm.stack.size > 1 || top != Screen.Home)) {
        if (!vm.back()) vm.resetTo(Screen.Home)
    }

    Crossfade(targetState = showSplash, animationSpec = tween(450), label = "splash") { splash ->
        if (splash) {
            SplashScreen()
        } else {
            NahidMain(vm, notify, snackbar, loggedIn, top, showBar, showFab)
        }
    }
}

@Composable
private fun NahidMain(
    vm: AppViewModel,
    notify: Notifier,
    snackbar: SnackbarHostState,
    loggedIn: Boolean,
    top: Screen,
    showBar: Boolean,
    showFab: Boolean
) {
    Scaffold(
        containerColor = Palette.Canvas,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = {
            SnackbarHost(
                hostState = snackbar,
                modifier = if (showBar) Modifier else Modifier.navigationBarsPadding().imePadding()
            ) { data ->
                Snackbar(
                    snackbarData = data,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(18.dp),
                    containerColor = Palette.InkDeep,
                    contentColor = Color.White
                )
            }
        },
        bottomBar = {
            if (showBar) AppTabs(top) { vm.selectTab(it) }
        },
        floatingActionButton = {
            if (showFab) {
                ExtendedFloatingActionButton(
                    onClick = { vm.open(Screen.Entry(-1, false)) },
                    shape = RoundedCornerShape(22.dp),
                    containerColor = Palette.Gold,
                    contentColor = Palette.OnGold,
                    elevation = FloatingActionButtonDefaults.elevation(
                        defaultElevation = 6.dp,
                        pressedElevation = 3.dp
                    ),
                    icon = { Glyph(R.drawable.ic_plus, Palette.OnGold) },
                    text = { Text("নতুন হিসাব", fontWeight = FontWeight.Bold, fontSize = 15.sp) }
                )
            }
        }
    ) { inner ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(bottom = inner.calculateBottomPadding())
                .imePadding()
        ) {
            when {
                !vm.ready -> FullscreenMessage("লোড হচ্ছে…")
                !loggedIn -> AccountScreen(vm, notify)
                else -> AnimatedContent(
                    targetState = top,
                    modifier = Modifier.fillMaxSize(),
                    transitionSpec = {
                        if (isTab(initialState) && isTab(targetState)) {
                            (fadeIn(animationSpec = tween(220)) + scaleIn(initialScale = 0.98f, animationSpec = tween(220))) togetherWith
                                fadeOut(animationSpec = tween(120))
                        } else if (vm.forward) {
                            (slideInHorizontally(animationSpec = tween(240), initialOffsetX = { it / 5 }) +
                                fadeIn(animationSpec = tween(240))) togetherWith
                                (slideOutHorizontally(animationSpec = tween(240), targetOffsetX = { -it / 8 }) +
                                    fadeOut(animationSpec = tween(160)))
                        } else {
                            (slideInHorizontally(animationSpec = tween(240), initialOffsetX = { -it / 8 }) +
                                fadeIn(animationSpec = tween(240))) togetherWith
                                (slideOutHorizontally(animationSpec = tween(240), targetOffsetX = { it / 5 }) +
                                    fadeOut(animationSpec = tween(160)))
                        }
                    },
                    label = "screen"
                ) { screen ->
                    ScreenHost(screen, vm, notify)
                }
            }
        }
    }
}
