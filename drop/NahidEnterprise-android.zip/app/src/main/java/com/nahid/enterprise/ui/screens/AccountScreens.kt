package com.nahid.enterprise.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nahid.enterprise.AppViewModel
import com.nahid.enterprise.R
import com.nahid.enterprise.ui.ActionsBox
import com.nahid.enterprise.ui.AppButton
import com.nahid.enterprise.ui.Brushes
import com.nahid.enterprise.ui.BtnKind
import com.nahid.enterprise.ui.Field
import com.nahid.enterprise.ui.GroupBox
import com.nahid.enterprise.ui.Hint
import com.nahid.enterprise.ui.KvRow
import com.nahid.enterprise.ui.Notifier
import com.nahid.enterprise.ui.Page
import com.nahid.enterprise.ui.Palette
import com.nahid.enterprise.ui.Rule
import com.nahid.enterprise.ui.SyncPill
import com.nahid.enterprise.ui.pullUp
import kotlinx.coroutines.launch

@Composable
fun AccountScreen(vm: AppViewModel, notify: Notifier) {
    var email by rememberSaveable { mutableStateOf("") }
    var pass by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val cloud = vm.cloud

    fun valid(): Boolean {
        val ok = email.trim().isNotEmpty() && pass.length >= 6
        if (!ok) notify.show("সঠিক Email এবং কমপক্ষে 6 অক্ষরের Password দিন")
        return ok
    }

    fun attempt(failure: String, action: suspend (String, String) -> Unit) {
        if (busy || !valid()) return
        busy = true
        val mail = email.trim()
        val secret = pass
        scope.launch {
            try {
                action(mail, secret)
            } catch (e: Exception) {
                notify.show(failure + ": " + cloud.describeError(e))
            }
            busy = false
        }
    }

    fun reset() {
        val mail = email.trim()
        if (mail.isEmpty()) {
            notify.show("আগে Email লিখুন")
            return
        }
        if (busy) return
        busy = true
        scope.launch {
            try {
                cloud.resetPassword(mail)
                notify.show("Password reset email পাঠানো হয়েছে")
            } catch (e: Exception) {
                notify.show("Email পাওয়া যায়নি")
            }
            busy = false
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Palette.Canvas)
            .verticalScroll(rememberScrollState())
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 40.dp, bottomEnd = 40.dp))
                .background(Brushes.Header)
                .drawBehind {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.06f),
                        radius = size.width * 0.42f,
                        center = Offset(size.width * 0.95f, size.height * 0.05f)
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = 0.05f),
                        radius = size.width * 0.3f,
                        center = Offset(size.width * 0.02f, size.height * 0.95f)
                    )
                }
                .statusBarsPadding()
                .padding(start = 24.dp, end = 24.dp, top = 56.dp, bottom = 84.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.logo),
                contentDescription = null,
                modifier = Modifier
                    .size(84.dp)
                    .shadow(16.dp, RoundedCornerShape(24.dp), clip = false)
            )
            Spacer(Modifier.height(20.dp))
            Text("Nahid Enterprise", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("আপনার দৈনিক ব্যবসার হিসাব", color = Color.White.copy(alpha = 0.78f), fontSize = 15.sp)
        }
        Column(
            Modifier
                .pullUp(52.dp)
                .padding(horizontal = 16.dp)
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                color = Color.White,
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 22.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Account Login", color = Palette.Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Field(
                        value = email,
                        onValueChange = { email = it },
                        label = "Email",
                        keyboard = KeyboardType.Email
                    )
                    Field(
                        value = pass,
                        onValueChange = { pass = it },
                        label = "Password",
                        password = true,
                        imeAction = ImeAction.Done
                    )
                    Spacer(Modifier.height(2.dp))
                    AppButton("Login", enabled = !busy) { attempt("Login হয়নি") { m, p -> cloud.login(m, p) } }
                    AppButton("নতুন Account তৈরি", kind = BtnKind.Tonal, enabled = !busy) {
                        attempt("Account তৈরি হয়নি") { m, p -> cloud.register(m, p) }
                    }
                    AppButton("Password ভুলে গেলে", kind = BtnKind.Text, enabled = !busy) { reset() }
                }
            }
            Hint("প্রথমবার Login করতে ইন্টারনেট লাগবে। এরপর অফলাইনেও অ্যাপ চলবে, নেটওয়ার্ক এলে ডেটা নিজে থেকে সিংক হবে।")
            Spacer(Modifier.height(28.dp))
            Spacer(Modifier.navigationBarsPadding())
        }
    }
}

@Composable
fun AccountInfoScreen(vm: AppViewModel, notify: Notifier) {
    val sync by vm.syncState.collectAsState()
    val scope = rememberCoroutineScope()
    val email = vm.session?.email.orEmpty()

    Box(Modifier.fillMaxSize()) {
        Page(
            title = "Account",
            sync = sync,
            onBack = null,
            edge = false,
            scrollState = vm.scrollState("account"),
            header = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .background(Brushes.Gold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = email.trim().take(1).uppercase().ifEmpty { "N" },
                            color = Palette.OnGold,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Nahid Enterprise", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = email,
                            color = Color.White.copy(alpha = 0.78f),
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        ) {
            GroupBox {
                KvRow("Login Email", email)
                Rule(18.dp)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 56.dp)
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Sync অবস্থা", color = Palette.Muted)
                    SyncPill(sync, color = Palette.Text)
                }
            }
            ActionsBox {
                AppButton("এখনই Cloud Sync") {
                    scope.launch {
                        val ok = vm.cloud.syncNow()
                        notify.show(if (ok) "Cloud Sync সম্পন্ন" else "নেটওয়ার্ক নেই — নেটওয়ার্ক এলে নিজে থেকে সিংক হবে")
                    }
                }
                AppButton("Logout", kind = BtnKind.Danger) { vm.cloud.logout() }
            }
            Spacer(Modifier.height(96.dp))
        }
        Text(
            text = "Developed by Tabib Imran",
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 10.dp),
            color = Palette.Muted.copy(alpha = 0.55f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
