package com.nahid.enterprise.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nahid.enterprise.AppViewModel
import com.nahid.enterprise.R
import com.nahid.enterprise.ui.ActionsBox
import com.nahid.enterprise.ui.AppButton
import com.nahid.enterprise.ui.BtnKind
import com.nahid.enterprise.ui.Field
import com.nahid.enterprise.ui.FieldsBox
import com.nahid.enterprise.ui.GroupBox
import com.nahid.enterprise.ui.Hint
import com.nahid.enterprise.ui.KvRow
import com.nahid.enterprise.ui.Notifier
import com.nahid.enterprise.ui.Page
import com.nahid.enterprise.ui.Palette
import com.nahid.enterprise.ui.Rule
import com.nahid.enterprise.ui.SyncPill
import kotlinx.coroutines.launch

@Composable
fun AccountScreen(vm: AppViewModel, notify: Notifier) {
    var email by rememberSaveable { mutableStateOf("") }
    var pass by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val cloud = vm.cloud

    fun valid(): Boolean {
        val ok = email.trim().isNotEmpty() && pass.length >= 6
        if (!ok) notify.show("সঠিক Email এবং কমপক্ষে 6 অক্ষরের Password দিন")
        return ok
    }

    fun attempt(failure: String, action: suspend (String, String) -> Unit) {
        if (busy || !valid()) return
        busy = true
        val mail = email.trim()
        val secret = pass
        scope.launch {
            try {
                action(mail, secret)
            } catch (e: Exception) {
                notify.show(failure + ": " + cloud.describeError(e))
            }
            busy = false
        }
    }

    fun reset() {
        val mail = email.trim()
        if (mail.isEmpty()) {
            notify.show("আগে Email লিখুন")
            return
        }
        if (busy) return
        busy = true
        scope.launch {
            try {
                cloud.resetPassword(mail)
                notify.show("Password reset email পাঠানো হয়েছে")
            } catch (e: Exception) {
                notify.show("Email পাওয়া যায়নি")
            }
            busy = false
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Palette.Canvas)
            .verticalScroll(rememberScrollState())
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(androidx.compose.ui.graphics.Color.White)
                .statusBarsPadding()
                .padding(start = 24.dp, end = 24.dp, top = 64.dp, bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.logo),
                contentDescription = null,
                modifier = Modifier.size(76.dp)
            )
            Spacer(Modifier.height(16.dp))
            Text("Nahid Enterprise", color = Palette.Ink, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Account Login", color = Palette.Muted)
        }
        FieldsBox {
            Field(
                value = email,
                onValueChange = { email = it },
                label = "Email",
                keyboard = KeyboardType.Email
            )
            Field(
                value = pass,
                onValueChange = { pass = it },
                label = "Password",
                password = true,
                imeAction = ImeAction.Done
            )
        }
        Hint("প্রথমবার Login করতে ইন্টারনেট লাগবে। এরপর অফলাইনেও অ্যাপ চলবে, নেটওয়ার্ক এলে ডেটা নিজে থেকে সিংক হবে।")
        ActionsBox {
            AppButton("Login", enabled = !busy) { attempt("Login হয়নি") { m, p -> cloud.login(m, p) } }
            AppButton("নতুন Account তৈরি", kind = BtnKind.Tonal, enabled = !busy) {
                attempt("Account তৈরি হয়নি") { m, p -> cloud.register(m, p) }
            }
            AppButton("Password ভুলে গেলে", kind = BtnKind.Text, enabled = !busy) { reset() }
        }
        Spacer(Modifier.navigationBarsPadding())
    }
}

@Composable
fun AccountInfoScreen(vm: AppViewModel, notify: Notifier) {
    val sync by vm.syncState.collectAsState()
    val scope = rememberCoroutineScope()
    val email = vm.session?.email.orEmpty()

    Page(
        title = "Account",
        sync = sync,
        onBack = null,
        edge = false,
        head = {
            Column(Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(androidx.compose.ui.graphics.Color.White)
                        .padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 14.dp)
                ) {
                    Text("Nahid Enterprise", color = Palette.Ink, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text(email, color = Palette.Muted)
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Palette.Soft)
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Sync অবস্থা", color = Palette.Ink, fontWeight = FontWeight.Medium)
                    SyncPill(sync, color = Palette.Ink, fontSize = 15.sp)
                }
            }
        }
    ) {
        Spacer(Modifier.height(8.dp))
        GroupBox {
            KvRow("Login Email", email)
            Rule()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 54.dp)
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Sync অবস্থা", color = Palette.Muted)
                SyncPill(sync, color = Palette.Text)
            }
        }
        ActionsBox {
            AppButton("এখনই Cloud Sync") {
                scope.launch {
                    val ok = vm.cloud.syncNow()
                    notify.show(if (ok) "Cloud Sync সম্পন্ন" else "নেটওয়ার্ক নেই — নেটওয়ার্ক এলে নিজে থেকে সিংক হবে")
                }
            }
            AppButton("Logout", kind = BtnKind.Danger) { vm.cloud.logout() }
        }
        Spacer(Modifier.height(24.dp))
    }
}
