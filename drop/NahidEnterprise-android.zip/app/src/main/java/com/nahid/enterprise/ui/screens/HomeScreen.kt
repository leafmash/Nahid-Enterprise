package com.nahid.enterprise.ui.screens

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nahid.enterprise.AppViewModel
import com.nahid.enterprise.R
import com.nahid.enterprise.ui.Avatar
import com.nahid.enterprise.ui.Brushes
import com.nahid.enterprise.ui.Chevron
import com.nahid.enterprise.ui.Group
import com.nahid.enterprise.ui.Heading
import com.nahid.enterprise.ui.ListRow
import com.nahid.enterprise.ui.Palette
import com.nahid.enterprise.ui.Screen
import com.nahid.enterprise.ui.SectionCard
import com.nahid.enterprise.ui.SyncDot
import com.nahid.enterprise.ui.Tile
import com.nahid.enterprise.ui.TitleBlock
import com.nahid.enterprise.ui.Tone
import com.nahid.enterprise.ui.pullUp
import com.nahid.enterprise.ui.syncLabel
import com.nahid.enterprise.util.dateKey
import com.nahid.enterprise.util.dayOfMonth
import com.nahid.enterprise.util.taka
import com.nahid.enterprise.util.today
import kotlin.math.roundToInt

private data class DayBar(val label: String, val total: Double, val now: Boolean)

private data class NavEntry(val icon: Int, val label: String, val sub: String, val tone: Tone, val go: () -> Unit)

private val CoverShape = RoundedCornerShape(bottomStart = 36.dp, bottomEnd = 36.dp)

@Composable
private fun MenuTile(entry: NavEntry, modifier: Modifier) {
    Surface(
        onClick = entry.go,
        modifier = modifier.height(150.dp),
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        shadowElevation = 1.dp,
        border = BorderStroke(1.dp, Palette.Line)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Tile(entry.icon, entry.tone, size = 46.dp)
            Column {
                Text(
                    text = entry.label,
                    color = Palette.Ink,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = entry.sub,
                    color = Palette.Muted,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, bg: Color, fg: Color, modifier: Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(bg)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Text(label, color = fg.copy(alpha = 0.8f), fontSize = 13.sp)
        Text(
            text = value,
            color = fg,
            fontSize = 19.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun HomeScreen(vm: AppViewModel) {
    val state by vm.appState.collectAsState()
    val sync by vm.syncState.collectAsState()

    val all = state.records
    val done = all.filter { !it.incomplete }
    val day = today()
    val month = day.drop(3)
    val todaySales = done.filter { it.date == day }.sumOf { it.total }
    val monthSales = done.filter { it.date.drop(3) == month }.sumOf { it.total }
    val pending = all.size - done.size
    val openDue = all.sumOf { rec -> rec.dues.sumOf { d -> if (d.paid) 0.0 else d.amount } }

    val bars = (6 downTo 0).map { ago ->
        val key = dateKey(ago)
        DayBar(dayOfMonth(ago), done.filter { it.date == key }.sumOf { it.total }, ago == 0)
    }
    val barMax = bars.maxOf { it.total }.coerceAtLeast(0.0)
    val weekTotal = bars.sumOf { it.total }

    val entries = listOf(
        NavEntry(
            R.drawable.ic_clock,
            "অসম্পূর্ণ হিসাব",
            if (pending > 0) "${pending}টি সম্পূর্ণ করা বাকি" else "সব হিসাব সম্পূর্ণ",
            Tone.Amber
        ) { vm.open(Screen.Incomplete) },
        NavEntry(R.drawable.ic_list, "আগের হিসাব", "মোট ${done.size}টি হিসাব", Tone.Blue) {
            vm.selectTab(Screen.History)
        },
        NavEntry(R.drawable.ic_box, "দ্রব্যের নাম ও দর", "${state.products.size}টি দ্রব্য", Tone.Green) {
            vm.open(Screen.Products)
        },
        NavEntry(R.drawable.ic_users, "বাকি ব্যক্তির তালিকা", "মোট বাকি ${taka(openDue)}", Tone.Red) {
            vm.selectTab(Screen.Dues)
        }
    )
    val accountEntry = NavEntry(R.drawable.ic_cloud, "Account / Logout", "সিংক ও লগআউট", Tone.Slate) {
        vm.selectTab(Screen.AccountInfo)
    }
    val recent = all.withIndex().filter { !it.value.incomplete }.reversed().take(4)

    val coverHeight = (LocalConfiguration.current.screenWidthDp * 0.7f).coerceIn(240f, 300f).dp

    var entered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { entered = true }
    val progress by animateFloatAsState(
        targetValue = if (entered) 1f else 0f,
        animationSpec = tween(750),
        label = "salesProgress"
    )
    val salesText = if (progress >= 1f) taka(todaySales) else taka(todaySales * progress)

    Column(
        Modifier
            .fillMaxSize()
            .background(Palette.Canvas)
            .verticalScroll(vm.scrollState("home"))
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(coverHeight)
                .clip(CoverShape)
                .background(Palette.Ink)
        ) {
            Image(
                painter = painterResource(R.drawable.home_photo),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alignment = BiasAlignment(0f, -0.2f),
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0f to Color(0x660B2A55),
                            0.3f to Color.Transparent,
                            0.55f to Color(0x330B2A55),
                            1f to Color(0xE6071C3B)
                        )
                    )
            )
            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .statusBarsPadding()
                    .padding(top = 14.dp, end = 18.dp)
                    .clip(CircleShape)
                    .background(Color(0x59000000))
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                SyncDot(sync, 8.dp)
                Text(syncLabel(sync), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 22.dp, end = 22.dp, bottom = 62.dp)
            ) {
                Text("Nahid Enterprise", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text(
                    "প্রো: মো আবু তালেব • দৈনিক ব্যবসার হিসাব",
                    color = Color.White.copy(alpha = 0.82f),
                    fontSize = 14.sp
                )
            }
        }

        Column(
            Modifier
                .pullUp(44.dp)
                .padding(horizontal = 16.dp)
        ) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                color = Color.White,
                shadowElevation = 6.dp
            ) {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 20.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("আজকের নিট বিক্রি", color = Palette.Muted, fontWeight = FontWeight.Medium)
                        Box(
                            Modifier
                                .clip(CircleShape)
                                .background(Palette.Soft)
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(day, color = Palette.Primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Text(
                        text = salesText,
                        color = Palette.Ink,
                        fontSize = 40.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        MiniStat("এই মাসের বিক্রি", taka(monthSales), Palette.Soft, Palette.Ink, Modifier.weight(1f))
                        MiniStat("মোট বাকি", taka(openDue), Palette.OpenBand, Palette.OpenText, Modifier.weight(1f))
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            SectionCard {
                Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text("শেষ ৭ দিনের বিক্রি", color = Palette.Ink, fontWeight = FontWeight.Bold)
                        Text(taka(weekTotal), color = Palette.Primary, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        bars.forEach { bar ->
                            val target = if (entered) {
                                if (barMax > 0) maxOf(8, ((maxOf(bar.total, 0.0) / barMax) * 84).roundToInt()) else 8
                            } else {
                                8
                            }
                            val barHeight by animateDpAsState(
                                targetValue = target.dp,
                                animationSpec = tween(650),
                                label = "bar"
                            )
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .width(28.dp)
                                        .height(84.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Palette.Field),
                                    contentAlignment = Alignment.BottomCenter
                                ) {
                                    Box(
                                        Modifier
                                            .fillMaxWidth()
                                            .height(barHeight)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (bar.now) Brushes.BarToday else Brushes.Bar)
                                    )
                                }
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = bar.label,
                                    color = if (bar.now) Palette.Ink else Palette.Muted,
                                    fontSize = 12.sp,
                                    fontWeight = if (bar.now) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            Heading("মেনু")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MenuTile(entries[0], Modifier.weight(1f))
                MenuTile(entries[1], Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MenuTile(entries[2], Modifier.weight(1f))
                MenuTile(entries[3], Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Group(listOf(accountEntry)) { entry ->
                ListRow(entry.go) {
                    Tile(entry.icon, entry.tone)
                    TitleBlock(entry.label, entry.sub)
                    Chevron()
                }
            }

            if (recent.isNotEmpty()) {
                Heading("সাম্প্রতিক হিসাব")
                Group(recent) { item ->
                    val o = item.value
                    ListRow({ vm.open(Screen.Detail(item.index)) }) {
                        Avatar(o.name)
                        TitleBlock(o.name.ifEmpty { "—" }, recordSub(o))
                        AmountText(o.finalAmount)
                    }
                }
            }
            Spacer(Modifier.height(112.dp))
        }
    }
}
