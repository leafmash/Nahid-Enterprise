package com.nahid.enterprise.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nahid.enterprise.AppViewModel
import com.nahid.enterprise.R
import com.nahid.enterprise.ui.Avatar
import com.nahid.enterprise.ui.Chevron
import com.nahid.enterprise.ui.Group
import com.nahid.enterprise.ui.Heading
import com.nahid.enterprise.ui.ListRow
import com.nahid.enterprise.ui.Palette
import com.nahid.enterprise.ui.Screen
import com.nahid.enterprise.ui.SyncDot
import com.nahid.enterprise.ui.Tile
import com.nahid.enterprise.ui.Tone
import com.nahid.enterprise.ui.TitleBlock
import com.nahid.enterprise.util.dateKey
import com.nahid.enterprise.util.dayOfMonth
import com.nahid.enterprise.util.fmt
import com.nahid.enterprise.util.taka
import com.nahid.enterprise.util.today
import kotlin.math.roundToInt

private fun Modifier.pullUp(amount: Dp): Modifier = layout { measurable, constraints ->
    val placeable = measurable.measure(constraints)
    val shift = amount.roundToPx()
    layout(placeable.width, placeable.height - shift) {
        placeable.place(0, -shift)
    }
}

private data class DayBar(val label: String, val total: Double, val now: Boolean)

private data class NavEntry(val icon: Int, val label: String, val sub: String, val tone: Tone, val go: () -> Unit)

@Composable
fun HomeScreen(vm: AppViewModel) {
    val state by vm.appState.collectAsState()
    val sync by vm.syncState.collectAsState()

    val all = state.records
    val done = all.filter { !it.incomplete }
    val day = today()
    val month = day.drop(3)
    val todaySales = done.filter { it.date == day }.sumOf { it.total }
    val monthSales = done.filter { it.date.drop(3) == month }.sumOf { it.total }
    val pending = all.size - done.size
    val openDue = all.sumOf { rec -> rec.dues.sumOf { d -> if (d.paid) 0.0 else d.amount } }

    val bars = (6 downTo 0).map { ago ->
        val key = dateKey(ago)
        DayBar(dayOfMonth(ago), done.filter { it.date == key }.sumOf { it.total }, ago == 0)
    }
    val barMax = bars.maxOf { it.total }.coerceAtLeast(0.0)
    val weekTotal = bars.sumOf { it.total }

    val entries = listOf(
        NavEntry(
            R.drawable.ic_clock,
            "অসম্পূর্ণ হিসাব",
            if (pending > 0) "${pending}টি সম্পূর্ণ করা বাকি" else "সব হিসাব সম্পূর্ণ",
            Tone.Amber
        ) { vm.open(Screen.Incomplete) },
        NavEntry(R.drawable.ic_list, "আগের হিসাব", "মোট ${done.size}টি হিসাব", Tone.Blue) {
            vm.selectTab(Screen.History)
        },
        NavEntry(R.drawable.ic_box, "দ্রব্যের নাম ও দর", "${state.products.size}টি দ্রব্য", Tone.Green) {
            vm.open(Screen.Products)
        },
        NavEntry(R.drawable.ic_users, "বাকি ব্যক্তির তালিকা", "মোট বাকি ${taka(openDue)}", Tone.Red) {
            vm.selectTab(Screen.Dues)
        },
        NavEntry(R.drawable.ic_cloud, "Account / Logout", "সিংক ও লগআউট", Tone.Slate) {
            vm.selectTab(Screen.AccountInfo)
        }
    )
    val recent = all.withIndex().filter { !it.value.incomplete }.reversed().take(4)

    val coverHeight = (LocalConfiguration.current.screenWidthDp * 0.66f).coerceIn(230f, 290f).dp

    Column(
        Modifier
            .fillMaxSize()
            .background(Palette.Canvas)
            .verticalScroll(rememberScrollState())
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(coverHeight)
                .background(Palette.Ink)
        ) {
            Image(
                painter = painterResource(R.drawable.home_photo),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alignment = BiasAlignment(0f, -0.2f),
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0f to Color(0x4D0B2A55),
                            0.26f to Color.Transparent
                        )
                    )
            )
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .statusBarsPadding()
                    .padding(top = 16.dp, end = 18.dp)
                    .background(Color(0x4D000000), CircleShape)
                    .padding(9.dp)
            ) {
                SyncDot(sync)
            }
        }

        Column(
            Modifier
                .pullUp(26.dp)
                .fillMaxWidth()
                .background(Color.White, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 22.dp)
        ) {
            Text("Nahid Enterprise", color = Palette.Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("প্রো: মো আবু তালেব • দৈনিক ব্যবসার হিসাব", color = Palette.Muted, fontSize = 15.sp)
            Spacer(Modifier.height(18.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Palette.Line))
            Spacer(Modifier.height(18.dp))
            Text("আজকের নিট বিক্রি", color = Palette.Muted)
            Text(taka(todaySales), color = Palette.Ink, fontSize = 42.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth().heightIn(min = 52.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("এই মাসের বিক্রি", color = Palette.Muted, fontSize = 13.sp)
                    Text(taka(monthSales), color = Palette.Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.width(1.dp).height(48.dp).background(Palette.Line))
                Column(Modifier.weight(1f).padding(start = 20.dp)) {
                    Text("মোট বাকি", color = Palette.Muted, fontSize = 13.sp)
                    Text(taka(openDue), color = Palette.Warn, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(22.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Palette.Line))
            Spacer(Modifier.height(18.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text("শেষ ৭ দিনের বিক্রি", color = Palette.Muted, fontSize = 14.sp)
                Text(taka(weekTotal), color = Palette.Ink, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(92.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                bars.forEach { bar ->
                    val barHeight = if (barMax > 0) {
                        maxOf(6, ((maxOf(bar.total, 0.0) / barMax) * 64).roundToInt())
                    } else {
                        6
                    }
                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        Box(
                            Modifier
                                .widthIn(max = 30.dp)
                                .fillMaxWidth()
                                .height(barHeight.dp)
                                .background(
                                    if (bar.now) Palette.Ink else Color(0xFFCFDCF3),
                                    RoundedCornerShape(8.dp)
                                )
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = bar.label,
                            color = if (bar.now) Palette.Ink else Palette.Muted,
                            fontSize = 12.sp,
                            fontWeight = if (bar.now) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Group(entries) { entry ->
            ListRow(entry.go) {
                Tile(entry.icon, entry.tone)
                TitleBlock(entry.label, entry.sub)
                Chevron()
            }
        }

        if (recent.isNotEmpty()) {
            Heading("সাম্প্রতিক হিসাব")
            Group(recent) { item ->
                val o = item.value
                ListRow({ vm.open(Screen.Detail(item.index)) }) {
                    Avatar(o.name)
                    TitleBlock(o.name.ifEmpty { "—" }, recordSub(o))
                    AmountText(o.finalAmount)
                }
            }
        }
        Spacer(Modifier.height(112.dp))
    }
}
