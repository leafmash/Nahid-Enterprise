package com.nahid.enterprise.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nahid.enterprise.data.Record
import com.nahid.enterprise.ui.Avatar
import com.nahid.enterprise.ui.Chevron
import com.nahid.enterprise.ui.ListRow
import com.nahid.enterprise.ui.Palette
import com.nahid.enterprise.ui.TitleBlock
import com.nahid.enterprise.util.taka

fun recordSub(o: Record): String =
    o.date + if (o.dest.isNotEmpty()) " • " + o.dest else ""

@Composable
fun AmountText(value: Double) {
    Text(
        text = taka(value),
        fontWeight = FontWeight.Bold,
        color = if (value < 0) Palette.Neg else Palette.Pos
    )
}

@Composable
fun RecordRow(o: Record, showChevron: Boolean, onClick: () -> Unit, trailing: @Composable () -> Unit) {
    ListRow(onClick) {
        Avatar(o.name)
        TitleBlock(o.name.ifEmpty { "—" }, recordSub(o))
        trailing()
        if (showChevron) Chevron()
    }
}

@Composable
fun HeroHead(title: String, sub: String, bandLabel: String, bandBg: Color, bandFg: Color, bandValue: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 14.dp)
        ) {
            Text(title, color = Palette.Ink, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            if (sub.isNotEmpty()) Text(sub, color = Palette.Muted)
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(bandBg)
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(bandLabel, color = bandFg, fontWeight = FontWeight.Medium)
            bandValue()
        }
    }
}
