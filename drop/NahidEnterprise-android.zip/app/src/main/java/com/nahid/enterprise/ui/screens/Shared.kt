package com.nahid.enterprise.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nahid.enterprise.data.PdfDownload
import com.nahid.enterprise.data.Record
import com.nahid.enterprise.data.SavedPdf
import com.nahid.enterprise.ui.Avatar
import com.nahid.enterprise.ui.Chevron
import com.nahid.enterprise.ui.ListRow
import com.nahid.enterprise.ui.Notifier
import com.nahid.enterprise.ui.Palette
import com.nahid.enterprise.ui.TitleBlock
import com.nahid.enterprise.util.taka

fun recordSub(o: Record): String =
    o.date + if (o.dest.isNotEmpty()) " • " + o.dest else ""

fun reportPdf(notify: Notifier, context: Context, saved: SavedPdf?, lead: String? = null) {
    val head = if (lead != null) "$lead — " else ""
    if (saved == null) {
        notify.show(head + "PDF সেভ করা যায়নি")
        return
    }
    notify.show(head + "PDF সেভ হয়েছে: ${saved.folder}", "খুলুন") {
        if (!PdfDownload.open(context, saved)) notify.show("PDF খোলার মতো অ্যাপ পাওয়া যায়নি")
    }
}

@Composable
fun AmountText(value: Double) {
    Text(
        text = taka(value),
        fontWeight = FontWeight.Bold,
        color = if (value < 0) Palette.Neg else Palette.Pos
    )
}

@Composable
fun RecordRow(o: Record, showChevron: Boolean, onClick: () -> Unit, trailing: @Composable () -> Unit) {
    ListRow(onClick) {
        Avatar(o.name)
        TitleBlock(o.name.ifEmpty { "—" }, recordSub(o))
        trailing()
        if (showChevron) Chevron()
    }
}

@Composable
fun RecordCard(o: Record, onClick: () -> Unit, trailing: @Composable () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp),
        shape = RoundedCornerShape(22.dp),
        color = Color.White,
        shadowElevation = 1.dp,
        border = BorderStroke(1.dp, Palette.Line)
    ) {
        Column {
            RecordRow(o = o, showChevron = true, onClick = onClick, trailing = trailing)
        }
    }
}
