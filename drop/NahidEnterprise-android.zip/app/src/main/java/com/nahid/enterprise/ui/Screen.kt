package com.nahid.enterprise.ui

sealed interface Screen {
    data object Home : Screen
    data object History : Screen
    data object Dues : Screen
    data object AccountInfo : Screen
    data object Incomplete : Screen
    data object Products : Screen
    data class Entry(val index: Int, val fromIncomplete: Boolean) : Screen
    data class Detail(val index: Int) : Screen
}

fun isTab(screen: Screen): Boolean =
    screen == Screen.Home || screen == Screen.History || screen == Screen.Dues || screen == Screen.AccountInfo
