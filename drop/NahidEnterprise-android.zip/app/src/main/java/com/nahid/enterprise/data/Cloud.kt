package com.nahid.enterprise.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

class Cloud(context: Context, private val store: Store) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val connectivity =
        appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val onlineFlow = MutableStateFlow(false)
    private val syncFlow = MutableStateFlow(SyncState.Synced)
    private var inflight: Deferred<Boolean>? = null

    val syncState: StateFlow<SyncState> = syncFlow.asStateFlow()

    private val auth: FirebaseAuth
        get() = FirebaseAuth.getInstance()

    private val db: FirebaseFirestore
        get() = FirebaseFirestore.getInstance()

    init {
        onlineFlow.value = queryOnline()
        connectivity.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                scope.launch {
                    onlineFlow.value = true
                    refresh()
                    syncPending()
                }
            }

            override fun onLost(network: Network) {
                scope.launch {
                    onlineFlow.value = false
                    refresh()
                }
            }
        })
        scope.launch {
            while (true) {
                delay(30_000)
                syncPending()
            }
        }
    }

    private fun queryOnline(): Boolean {
        val network = connectivity.activeNetwork ?: return false
        val caps = connectivity.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun refresh() {
        syncFlow.value = when {
            inflight != null -> SyncState.Syncing
            !onlineFlow.value -> SyncState.Offline
            store.isDirty() -> SyncState.Pending
            else -> SyncState.Synced
        }
    }

    fun currentSession(): Session? =
        auth.currentUser?.let { Session(it.uid, it.email.orEmpty()) }

    fun addAuthListener(listener: FirebaseAuth.AuthStateListener) {
        auth.addAuthStateListener(listener)
    }

    fun removeAuthListener(listener: FirebaseAuth.AuthStateListener) {
        auth.removeAuthStateListener(listener)
    }

    fun describeError(error: Throwable): String {
        if (error is FirebaseNetworkException) return "ইন্টারনেট সংযোগ পাওয়া যায়নি"
        if (error is FirebaseAuthException) {
            return when (error.errorCode) {
                "ERROR_INVALID_EMAIL" -> "Email সঠিক নয়"
                "ERROR_WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL" -> "Email বা Password ভুল"
                "ERROR_USER_NOT_FOUND" -> "এই Email দিয়ে কোনো Account নেই"
                "ERROR_EMAIL_ALREADY_IN_USE" -> "এই Email দিয়ে আগেই Account আছে"
                "ERROR_WEAK_PASSWORD" -> "Password দুর্বল, আরও শক্ত দিন"
                "ERROR_USER_DISABLED" -> "এই Account বন্ধ করা আছে"
                "ERROR_TOO_MANY_REQUESTS" -> "অনেকবার চেষ্টা হয়েছে, একটু পরে আবার চেষ্টা করুন"
                else -> error.message ?: "অজানা সমস্যা"
            }
        }
        return error.message ?: "অজানা সমস্যা"
    }

    private fun requireNetwork() {
        if (!onlineFlow.value) throw IllegalStateException("প্রথমবার Login করতে ইন্টারনেট লাগবে")
    }

    suspend fun login(email: String, pass: String) {
        requireNetwork()
        auth.signInWithEmailAndPassword(email, pass).await()
    }

    suspend fun register(email: String, pass: String) {
        requireNetwork()
        auth.createUserWithEmailAndPassword(email, pass).await()
    }

    suspend fun resetPassword(email: String) {
        requireNetwork()
        auth.sendPasswordResetEmail(email).await()
    }

    fun logout() {
        auth.signOut()
    }

    private suspend fun push(): Boolean {
        return try {
            val user = auth.currentUser ?: return false
            val mark = store.rev()
            val payload = HashMap<String, Any>(store.exportCloud())
            payload["updatedAt"] = System.currentTimeMillis()
            val done = withTimeoutOrNull(12_000) {
                db.collection("users").document(user.uid).set(payload, SetOptions.merge()).await()
                true
            }
            if (done != true) return false
            if (store.rev() == mark) store.setDirty(false)
            true
        } catch (e: Exception) {
            false
        }
    }

    private suspend fun runPush(): Boolean {
        val ok = try {
            push()
        } finally {
            inflight = null
        }
        refresh()
        if (ok && store.isDirty()) {
            scope.launch {
                delay(200)
                syncPending()
            }
        }
        return ok
    }

    suspend fun syncPending(): Boolean {
        inflight?.let { return it.await() }
        if (!store.isDirty()) {
            refresh()
            return true
        }
        if (!onlineFlow.value) {
            refresh()
            return false
        }
        val job = scope.async { runPush() }
        inflight = job
        refresh()
        return job.await()
    }

    fun saveCloud() {
        store.setDirty(true)
        refresh()
        scope.launch { syncPending() }
    }

    suspend fun syncNow(): Boolean {
        store.setDirty(true)
        return syncPending()
    }

    suspend fun load(): LoadStatus {
        val user = auth.currentUser ?: return LoadStatus.None
        if (store.isDirty()) {
            syncPending()
            return LoadStatus.Pending
        }
        if (!onlineFlow.value) return LoadStatus.Offline
        return try {
            val snap = withTimeoutOrNull(10_000) {
                db.collection("users").document(user.uid).get(Source.SERVER).await()
            } ?: return LoadStatus.Error
            if (store.isDirty()) return LoadStatus.Pending
            if (!snap.exists()) return LoadStatus.Missing
            val data = snap.data ?: return LoadStatus.Missing
            store.importCloud(data)
            LoadStatus.Loaded
        } catch (e: Exception) {
            LoadStatus.Error
        }
    }
}
