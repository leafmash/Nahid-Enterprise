package com.nahid.enterprise.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nahid.enterprise.R

private val SplashBackground = Color(0xFFFCF9F0)
private val SplashGreen = Color(0xFF1B7A43)
private val SplashGold = Color(0xFFD4AF37)
private val SplashText = Color(0xFF0F5A32)
private val SplashMuted = Color(0xFF6E7F73)

@Composable
fun SplashScreen() {
    var entered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { entered = true }

    val logoProgress by animateFloatAsState(
        targetValue = if (entered) 1f else 0f,
        animationSpec = tween(700),
        label = "splashLogo"
    )
    val textProgress by animateFloatAsState(
        targetValue = if (entered) 1f else 0f,
        animationSpec = tween(700, delayMillis = 350),
        label = "splashText"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SplashBackground)
            .drawBehind {
                drawCircle(
                    color = SplashGreen.copy(alpha = 0.07f),
                    radius = size.width * 0.62f,
                    center = Offset(size.width * 1.0f, size.height * 0.02f)
                )
                drawCircle(
                    color = SplashGold.copy(alpha = 0.12f),
                    radius = size.width * 0.42f,
                    center = Offset(0f, size.height * 0.98f)
                )
            }
    ) {
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.splash_logo),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .graphicsLayer {
                        val scale = 0.8f + 0.2f * logoProgress
                        scaleX = scale
                        scaleY = scale
                        alpha = logoProgress
                    }
            )
        }
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 36.dp)
                .alpha(textProgress),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text("প্রো: মো আবু তালেব", color = SplashText.copy(alpha = 0.8f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text("লোড হচ্ছে…", color = SplashMuted, fontSize = 12.sp)
        }
    }
}
