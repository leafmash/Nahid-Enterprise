package com.nahid.enterprise.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nahid.enterprise.R

@Composable
fun SplashScreen() {
    var entered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { entered = true }

    val logoProgress by animateFloatAsState(
        targetValue = if (entered) 1f else 0f,
        animationSpec = tween(700),
        label = "splashLogo"
    )
    val textProgress by animateFloatAsState(
        targetValue = if (entered) 1f else 0f,
        animationSpec = tween(700, delayMillis = 350),
        label = "splashText"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Palette.Canvas)
            .drawBehind {
                drawCircle(
                    color = Palette.Primary.copy(alpha = 0.06f),
                    radius = size.width * 0.62f,
                    center = Offset(size.width * 1.0f, size.height * 0.02f)
                )
                drawCircle(
                    color = Palette.Gold.copy(alpha = 0.10f),
                    radius = size.width * 0.42f,
                    center = Offset(0f, size.height * 0.98f)
                )
            }
    ) {
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.logo),
                contentDescription = null,
                modifier = Modifier
                    .size(136.dp)
                    .graphicsLayer {
                        val scale = 0.7f + 0.3f * logoProgress
                        scaleX = scale
                        scaleY = scale
                        alpha = logoProgress
                    }
                    .shadow(18.dp, RoundedCornerShape(34.dp), clip = false)
            )
            Spacer(Modifier.height(30.dp))
            Column(
                modifier = Modifier
                    .alpha(textProgress)
                    .graphicsLayer { translationY = (1f - textProgress) * 24f },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Nahid Enterprise",
                    color = Palette.Ink,
                    fontSize = 31.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier
                        .width(48.dp)
                        .height(4.dp)
                        .background(Brushes.Gold, RoundedCornerShape(2.dp))
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    text = "দৈনিক ব্যবসার হিসাব",
                    color = Palette.Muted,
                    fontSize = 15.sp
                )
            }
        }
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 36.dp)
                .alpha(textProgress),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text("প্রো: মো আবু তালেব", color = Palette.Ink.copy(alpha = 0.7f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text("লোড হচ্ছে…", color = Color(0xFF9AA4B6), fontSize = 12.sp)
        }
    }
}
