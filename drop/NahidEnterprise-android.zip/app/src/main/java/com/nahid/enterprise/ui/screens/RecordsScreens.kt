package com.nahid.enterprise.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nahid.enterprise.AppViewModel
import com.nahid.enterprise.R
import com.nahid.enterprise.data.Export
import com.nahid.enterprise.ui.ActionsBox
import com.nahid.enterprise.ui.AppButton
import com.nahid.enterprise.ui.Badge
import com.nahid.enterprise.ui.BtnKind
import com.nahid.enterprise.ui.ConfirmDialog
import com.nahid.enterprise.ui.EmptyNote
import com.nahid.enterprise.ui.Glyph
import com.nahid.enterprise.ui.Group
import com.nahid.enterprise.ui.GroupBox
import com.nahid.enterprise.ui.HeadNote
import com.nahid.enterprise.ui.Heading
import com.nahid.enterprise.ui.KvRow
import com.nahid.enterprise.ui.Notifier
import com.nahid.enterprise.ui.NoteBox
import com.nahid.enterprise.ui.Page
import com.nahid.enterprise.ui.Palette
import com.nahid.enterprise.ui.Rule
import com.nahid.enterprise.ui.Screen
import com.nahid.enterprise.util.fmt
import com.nahid.enterprise.util.taka

@Composable
fun IncompleteScreen(vm: AppViewModel) {
    val state by vm.appState.collectAsState()
    val sync by vm.syncState.collectAsState()
    val list = state.records.withIndex().filter { it.value.incomplete }.reversed()

    Page(
        title = "অসম্পূর্ণ হিসাব",
        sync = sync,
        onBack = { vm.back() },
        scrollState = vm.scrollState("incomplete"),
        head = {
            HeadNote(if (list.isNotEmpty()) "${list.size}টি হিসাব সম্পূর্ণ করা বাকি" else "সব হিসাব সম্পূর্ণ")
        }
    ) {
        Spacer(Modifier.height(8.dp))
        if (list.isEmpty()) {
            EmptyNote("কোনো অসম্পূর্ণ হিসাব নেই।")
        } else {
            Group(list) { item ->
                RecordRow(
                    o = item.value,
                    showChevron = true,
                    onClick = { vm.open(Screen.Entry(item.index, true)) }
                ) {
                    Badge("অসম্পূর্ণ", paid = false)
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(vm: AppViewModel) {
    val state by vm.appState.collectAsState()
    val sync by vm.syncState.collectAsState()
    val query = vm.historyQuery
    val q = query.trim().lowercase()
    val rows = state.records.withIndex().filter { item ->
        val o = item.value
        !o.incomplete && (q.isEmpty() || "${o.name} ${o.dest} ${o.date}".lowercase().contains(q))
    }.reversed()

    Page(
        title = "আগের হিসাব",
        sync = sync,
        onBack = null,
        scroll = false,
        edge = false,
        head = {
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { vm.historyQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("নাম / গন্তব্য / তারিখ / মাস দিয়ে Search", maxLines = 1, fontSize = 15.sp) },
                    leadingIcon = { Glyph(R.drawable.ic_search, Palette.Primary, size = 22.dp) },
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 16.sp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Search),
                    shape = RoundedCornerShape(26.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Palette.Field,
                        unfocusedContainerColor = Palette.Field,
                        focusedBorderColor = Palette.Primary,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = Palette.Text,
                        unfocusedTextColor = Palette.Text,
                        cursorColor = Palette.Primary,
                        focusedPlaceholderColor = Palette.Muted,
                        unfocusedPlaceholderColor = Palette.Muted
                    )
                )
            }
        }
    ) {
        if (rows.isEmpty()) {
            Spacer(Modifier.height(8.dp))
            EmptyNote("কোনো হিসাব পাওয়া যায়নি।")
        } else {
            LazyColumn(
                state = vm.listState("history"),
                modifier = Modifier.fillMaxSize().background(Color.White)
            ) {
                items(rows, key = { it.index }) { item ->
                    Column {
                        RecordRow(
                            o = item.value,
                            showChevron = true,
                            onClick = { vm.open(Screen.Detail(item.index)) }
                        ) {
                            AmountText(item.value.finalAmount)
                        }
                        Rule()
                    }
                }
                item { Spacer(Modifier.height(112.dp).background(Palette.Canvas).fillMaxWidth()) }
            }
        }
    }
}

@Composable
fun DetailScreen(vm: AppViewModel, notify: Notifier, index: Int) {
    val state by vm.appState.collectAsState()
    val sync by vm.syncState.collectAsState()
    val context = LocalContext.current
    var confirmDelete by remember { mutableStateOf(false) }
    val o = state.records.getOrNull(index)

    if (o == null) {
        LaunchedEffect(Unit) {
            if (vm.stack.last() is Screen.Detail) vm.back()
        }
        return
    }

    val positive = o.finalAmount >= 0

    Page(
        title = "হিসাব বিস্তারিত",
        sync = sync,
        onBack = { vm.back() },
        scrollState = vm.scrollState("detail:$index"),
        head = {
            HeroHead(
                title = o.name.ifEmpty { "—" },
                sub = recordSub(o),
                bandLabel = "চূড়ান্ত হিসাব",
                bandBg = if (positive) Palette.PosBand else Palette.NegBand,
                bandFg = if (positive) Palette.Pos else Palette.Neg
            ) {
                Text(
                    taka(o.finalAmount),
                    color = if (positive) Palette.Pos else Palette.Neg,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    ) {
        Heading("দ্রব্যের হিসাব")
        if (o.products.isEmpty()) {
            EmptyNote("কোনো দ্রব্য নেই।")
        } else {
            Group(o.products) { x ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(x.product, fontWeight = FontWeight.SemiBold)
                        Text(
                            "পরিমাণ ${fmt(x.qty)} • ফেরত ${fmt(x.ret)} • দর ${taka(x.rate)}",
                            color = Palette.Muted,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(Modifier.padding(start = 16.dp))
                    Text(taka(x.net), color = Palette.Ink, fontWeight = FontWeight.Bold)
                }
            }
        }
        Heading("হিসাব")
        GroupBox {
            KvRow("মোট নিট বিক্রি", taka(o.total))
            Rule()
            KvRow("ডেমেজ", taka(o.damage))
            Rule()
            KvRow("হ্যান্ড ক্যাশ", taka(o.cash))
        }
        Heading("বাকি")
        if (o.dues.isEmpty()) {
            EmptyNote("কোনো বাকি নেই।")
        } else {
            Group(o.dues) { x ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(x.name, fontWeight = FontWeight.SemiBold)
                        Text(taka(x.amount), color = Palette.Muted, fontSize = 14.sp)
                    }
                    Badge(if (x.paid) "PAID" else "বর্তমান বাকি", paid = x.paid)
                }
            }
        }
        if (o.comment.isNotEmpty()) {
            Heading("মন্তব্য")
            NoteBox(o.comment)
        }
        ActionsBox {
            AppButton("Edit / Correction") { vm.open(Screen.Entry(index, false)) }
            AppButton("Phone Storage-এ File Save", kind = BtnKind.Tonal) {
                val ok = Export.saveToPhone(context, o)
                notify.show(if (ok) "File Save হয়েছে" else "File Save করা যায়নি")
            }
            AppButton("হিসাব Delete", kind = BtnKind.Danger) { confirmDelete = true }
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = "হিসাব Delete?",
            message = "এই হিসাবটি স্থায়ীভাবে মুছে যাবে।",
            ok = "Delete",
            cancel = "বাতিল",
            onConfirm = {
                confirmDelete = false
                vm.resetTo(Screen.History)
                vm.deleteRecord(index)
                notify.show("হিসাব Delete হয়েছে")
            },
            onDismiss = { confirmDelete = false }
        )
    }
}
