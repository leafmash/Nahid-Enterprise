package com.nahid.enterprise.ui

import androidx.activity.compose.BackHandler
import androidx.annotation.DrawableRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nahid.enterprise.R
import com.nahid.enterprise.data.SyncState

fun syncLabel(state: SyncState): String = when (state) {
    SyncState.Synced -> "সিংক হয়েছে"
    SyncState.Syncing -> "সিংক হচ্ছে…"
    SyncState.Pending -> "সিংক বাকি"
    SyncState.Offline -> "অফলাইন"
}

fun Modifier.pullUp(amount: Dp): Modifier = layout { measurable, constraints ->
    val placeable = measurable.measure(constraints)
    val shift = amount.roundToPx()
    layout(placeable.width, placeable.height - shift) {
        placeable.place(0, -shift)
    }
}

@Composable
fun Glyph(@DrawableRes id: Int, tint: Color, modifier: Modifier = Modifier, size: Dp = 24.dp) {
    Icon(
        painter = painterResource(id),
        contentDescription = null,
        tint = tint,
        modifier = modifier.size(size)
    )
}

@Composable
fun SyncDot(state: SyncState, size: Dp = 10.dp) {
    val color = when (state) {
        SyncState.Synced -> Color(0xFF3DDC97)
        SyncState.Syncing -> Color(0xFF7FB0FF)
        SyncState.Pending, SyncState.Offline -> Color(0xFFFFC145)
    }
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse = transition.animateFloat(
        initialValue = 1f,
        targetValue = 0.25f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulseAlpha"
    )
    val alpha = if (state == SyncState.Syncing) pulse.value else 1f
    Box(
        Modifier
            .size(size)
            .alpha(alpha)
            .background(color, CircleShape)
    )
}

@Composable
fun SyncPill(state: SyncState, color: Color = Palette.Muted, fontSize: TextUnit = 14.sp) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        SyncDot(state, 8.dp)
        Text(syncLabel(state), color = color, fontSize = fontSize, fontWeight = FontWeight.Medium)
    }
}

private val HeaderShape = RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp)

@Composable
private fun TopBar(
    title: String,
    sync: SyncState,
    onBack: (() -> Unit)?,
    extra: (@Composable ColumnScope.() -> Unit)?
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(HeaderShape)
            .background(Brushes.Header)
            .drawBehind {
                drawCircle(
                    color = Color.White.copy(alpha = 0.06f),
                    radius = size.width * 0.38f,
                    center = Offset(size.width * 0.96f, size.height * 0.08f)
                )
                drawCircle(
                    color = Color.White.copy(alpha = 0.05f),
                    radius = size.width * 0.26f,
                    center = Offset(size.width * 0.04f, size.height * 1.02f)
                )
            }
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 68.dp)
                .padding(start = if (onBack != null) 14.dp else 22.dp, end = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBack != null) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.14f))
                        .clickable(role = Role.Button, onClick = onBack)
                        .semantics { contentDescription = "পেছনে" },
                    contentAlignment = Alignment.Center
                ) {
                    Glyph(R.drawable.ic_back, Color.White, size = 22.dp)
                }
            }
            Text(
                text = title,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = if (onBack != null) 14.dp else 0.dp, end = 12.dp),
                color = Color.White,
                fontSize = 21.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(Color.White.copy(alpha = 0.14f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                SyncDot(sync)
            }
        }
        if (extra != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 22.dp, end = 22.dp, top = 2.dp, bottom = 28.dp),
                content = extra
            )
        } else {
            Spacer(Modifier.height(14.dp))
        }
    }
}

@Composable
fun Page(
    title: String,
    sync: SyncState,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    header: (@Composable ColumnScope.() -> Unit)? = null,
    bottom: (@Composable () -> Unit)? = null,
    scroll: Boolean = true,
    edge: Boolean = true,
    scrollState: ScrollState? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val pageScroll = scrollState ?: rememberScrollState()
    Column(modifier.fillMaxSize().background(Palette.Canvas)) {
        TopBar(title, sync, onBack, header)
        if (scroll) {
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(pageScroll)
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(Modifier.height(16.dp))
                content()
                Spacer(Modifier.height(24.dp))
                if (edge && bottom == null) Spacer(Modifier.navigationBarsPadding())
            }
        } else {
            Column(Modifier.weight(1f).fillMaxWidth()) {
                content()
            }
        }
        bottom?.invoke()
    }
}

@Composable
fun ColumnScope.HeaderNote(text: String) {
    Text(
        text = text,
        color = Color.White.copy(alpha = 0.8f),
        fontSize = 15.sp,
        modifier = Modifier.padding(top = 2.dp)
    )
}

@Composable
fun ColumnScope.HeaderHero(
    title: String,
    sub: String,
    bandLabel: String,
    value: String,
    valueColor: Color
) {
    Text(
        text = title,
        color = Color.White,
        fontSize = 28.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
    )
    if (sub.isNotEmpty()) {
        Text(sub, color = Color.White.copy(alpha = 0.74f), fontSize = 15.sp)
    }
    Spacer(Modifier.height(18.dp))
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(Shapes.Control)
            .background(Color.White.copy(alpha = 0.13f))
            .padding(horizontal = 18.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(bandLabel, color = Color.White.copy(alpha = 0.88f), fontWeight = FontWeight.Medium)
        Text(value, color = valueColor, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    }
}

enum class BtnKind { Primary, Gold, Tonal, Text, Danger }

@Composable
fun AppButton(
    label: String,
    modifier: Modifier = Modifier,
    kind: BtnKind = BtnKind.Primary,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val brush: Brush = when (kind) {
        BtnKind.Primary -> Brushes.Primary
        BtnKind.Gold -> Brushes.Gold
        BtnKind.Tonal -> SolidColor(Palette.Soft)
        BtnKind.Danger -> SolidColor(Palette.NegBand)
        BtnKind.Text -> SolidColor(Color.Transparent)
    }
    val content = when (kind) {
        BtnKind.Primary -> Color.White
        BtnKind.Gold -> Palette.OnGold
        BtnKind.Tonal -> Palette.Ink
        BtnKind.Text -> Palette.Primary
        BtnKind.Danger -> Palette.Neg
    }
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "buttonPress"
    )
    Box(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .alpha(if (enabled) 1f else 0.5f)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(Shapes.Control)
            .background(brush)
            .clickable(
                interactionSource = source,
                indication = LocalIndication.current,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
            color = content,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun Field(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    keyboard: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Next,
    password: Boolean = false,
    singleLine: Boolean = true,
    minLines: Int = 1,
    placeholder: (@Composable () -> Unit)? = null,
    leading: (@Composable () -> Unit)? = null,
    shape: RoundedCornerShape = RoundedCornerShape(16.dp)
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        label = { Text(label, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        placeholder = placeholder,
        leadingIcon = leading,
        singleLine = singleLine,
        minLines = minLines,
        textStyle = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.Medium),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (password) KeyboardType.Password else keyboard,
            imeAction = imeAction
        ),
        shape = shape,
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Palette.Field,
            focusedBorderColor = Palette.Primary,
            unfocusedBorderColor = Palette.Line,
            focusedLabelColor = Palette.Primary,
            unfocusedLabelColor = Palette.Muted,
            focusedTextColor = Palette.Text,
            unfocusedTextColor = Palette.Text,
            cursorColor = Palette.Primary,
            focusedPlaceholderColor = Palette.Muted,
            unfocusedPlaceholderColor = Palette.Muted
        )
    )
}

@Composable
fun SectionCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = Shapes.Card,
        color = Color.White,
        shadowElevation = 1.dp,
        border = BorderStroke(1.dp, Palette.Line)
    ) {
        Column(content = content)
    }
}

@Composable
fun FieldsBox(content: @Composable ColumnScope.() -> Unit) {
    SectionCard {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            content = content
        )
    }
}

@Composable
fun Heading(text: String) {
    Row(
        modifier = Modifier.padding(start = 6.dp, end = 6.dp, top = 26.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(8.dp)
                .background(Brushes.Gold, CircleShape)
        )
        Spacer(Modifier.width(10.dp))
        Text(text, color = Palette.Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun Hint(text: String) {
    Text(
        text = text,
        modifier = Modifier.padding(start = 6.dp, end = 6.dp, top = 12.dp),
        color = Palette.Muted,
        fontSize = 13.5.sp,
        lineHeight = 21.sp
    )
}

@Composable
fun EmptyNote(text: String, @DrawableRes icon: Int = R.drawable.ic_list) {
    SectionCard {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier
                    .size(60.dp)
                    .background(Palette.Soft, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Glyph(icon, Palette.Primary, size = 28.dp)
            }
            Spacer(Modifier.height(14.dp))
            Text(text, color = Palette.Muted, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun NoteBox(text: String) {
    SectionCard {
        Text(
            text = text,
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            lineHeight = 26.sp
        )
    }
}

@Composable
fun Rule(inset: Dp = 0.dp) {
    HorizontalDivider(modifier = Modifier.padding(start = inset), color = Palette.Line, thickness = 1.dp)
}

@Composable
fun GroupBox(content: @Composable ColumnScope.() -> Unit) {
    SectionCard(content = content)
}

@Composable
fun <T> Group(items: List<T>, inset: Dp = 78.dp, content: @Composable (T) -> Unit) {
    SectionCard {
        items.forEachIndexed { index, item ->
            if (index > 0) Rule(inset)
            content(item)
        }
    }
}

@Composable
fun ActionsBox(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 22.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun ListRow(onClick: (() -> Unit)?, content: @Composable RowScope.() -> Unit) {
    val base = Modifier
        .fillMaxWidth()
        .heightIn(min = 70.dp)
    Row(
        modifier = (if (onClick != null) base.clickable(onClick = onClick) else base)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
fun RowScope.TitleBlock(title: String, sub: String?, subColor: Color = Palette.Muted) {
    Column(Modifier.weight(1f)) {
        Text(
            text = title,
            fontWeight = FontWeight.SemiBold,
            fontSize = 16.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (!sub.isNullOrEmpty()) {
            Text(
                text = sub,
                color = subColor,
                fontSize = 13.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun Chevron() {
    Glyph(R.drawable.ic_chevron, Palette.Chevron, size = 20.dp)
}

@Composable
fun Avatar(name: String) {
    val text = name.trim()
    val letter = if (text.isEmpty()) "•" else String(Character.toChars(text.codePointAt(0)))
    val code = text.sumOf { it.code }
    val (bg, fg) = when (code % 5) {
        0 -> Palette.Soft to Palette.Primary
        1 -> Palette.PosBand to Palette.Pos
        2 -> Palette.OpenBand to Palette.Warn
        3 -> Palette.NegBand to Color(0xFFB02F26)
        else -> Color(0xFFECE4F8) to Color(0xFF5A3AA0)
    }
    Box(
        modifier = Modifier
            .size(46.dp)
            .background(bg, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(letter, color = fg, fontSize = 19.sp, fontWeight = FontWeight.Bold)
    }
}

enum class Tone { Amber, Blue, Green, Red, Slate }

@Composable
fun Tile(@DrawableRes icon: Int, tone: Tone, size: Dp = 48.dp) {
    val (bg, fg) = when (tone) {
        Tone.Amber -> Palette.OpenBand to Palette.Warn
        Tone.Blue -> Palette.Soft to Palette.Primary
        Tone.Green -> Palette.PosBand to Palette.Pos
        Tone.Red -> Palette.NegBand to Palette.Neg
        Tone.Slate -> Color(0xFFE8EBF1) to Color(0xFF4B566B)
    }
    Box(
        modifier = Modifier
            .size(size)
            .background(bg, RoundedCornerShape(16.dp)),
        contentAlignment = Alignment.Center
    ) {
        Glyph(icon, fg)
    }
}

@Composable
fun Badge(text: String, paid: Boolean) {
    Box(
        modifier = Modifier
            .background(if (paid) Palette.PosBand else Palette.OpenBand, CircleShape)
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            color = if (paid) Palette.Pos else Palette.OpenText,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

@Composable
fun KvRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Palette.Muted)
        Spacer(Modifier.width(16.dp))
        Text(
            text = value,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    ok: String,
    cancel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    danger: Boolean = false
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(28.dp),
        title = { Text(title, color = Palette.Ink, fontWeight = FontWeight.Bold) },
        text = { Text(message, color = Palette.Muted) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(
                    text = ok,
                    color = if (danger) Palette.Neg else Palette.Primary,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(cancel, color = Palette.Muted)
            }
        }
    )
}

@Composable
fun TrashButton(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(42.dp)
            .clip(CircleShape)
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) {
        Glyph(R.drawable.ic_trash, Palette.Trash, size = 22.dp)
    }
}

@Composable
fun FullscreenMessage(text: String) {
    Box(Modifier.fillMaxSize().background(Palette.Canvas), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(R.drawable.logo),
                contentDescription = null,
                modifier = Modifier.size(72.dp)
            )
            Spacer(Modifier.height(22.dp))
            CircularProgressIndicator(
                modifier = Modifier.size(28.dp),
                color = Palette.Primary,
                strokeWidth = 3.dp
            )
            Spacer(Modifier.height(14.dp))
            Text(text, color = Palette.Muted)
        }
    }
}

@Composable
fun LoadingOverlay(visible: Boolean, message: String) {
    BackHandler(enabled = visible) {}
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(160)),
        exit = fadeOut(tween(220))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Palette.InkDeep.copy(alpha = 0.55f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                ),
            contentAlignment = Alignment.Center
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn(tween(200)) + scaleIn(initialScale = 0.9f, animationSpec = tween(200)),
                exit = fadeOut(tween(160)) + scaleOut(targetScale = 0.95f, animationSpec = tween(160))
            ) {
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = Color.White,
                    shadowElevation = 16.dp
                ) {
                    Column(
                        modifier = Modifier
                            .widthIn(min = 200.dp, max = 280.dp)
                            .padding(horizontal = 28.dp, vertical = 26.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(40.dp),
                            color = Palette.Primary,
                            trackColor = Palette.Soft,
                            strokeWidth = 4.dp
                        )
                        Spacer(Modifier.height(18.dp))
                        Text(
                            text = message,
                            color = Palette.Ink,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}
