package com.nahid.enterprise.ui

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nahid.enterprise.R
import com.nahid.enterprise.data.SyncState

fun syncLabel(state: SyncState): String = when (state) {
    SyncState.Synced -> "সিংক হয়েছে"
    SyncState.Syncing -> "সিংক হচ্ছে…"
    SyncState.Pending -> "সিংক বাকি"
    SyncState.Offline -> "অফলাইন"
}

@Composable
fun Glyph(@DrawableRes id: Int, tint: Color, modifier: Modifier = Modifier, size: Dp = 24.dp) {
    Icon(
        painter = painterResource(id),
        contentDescription = null,
        tint = tint,
        modifier = modifier.size(size)
    )
}

@Composable
fun SyncDot(state: SyncState, size: Dp = 10.dp) {
    val color = when (state) {
        SyncState.Synced -> Color(0xFF2FBF86)
        SyncState.Syncing -> Color(0xFF5B8FE0)
        SyncState.Pending, SyncState.Offline -> Color(0xFFE0A21A)
    }
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse = transition.animateFloat(
        initialValue = 1f,
        targetValue = 0.25f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulseAlpha"
    )
    val alpha = if (state == SyncState.Syncing) pulse.value else 1f
    Box(
        Modifier
            .size(size)
            .alpha(alpha)
            .background(color, CircleShape)
    )
}

@Composable
fun SyncPill(state: SyncState, color: Color = Palette.Muted, fontSize: TextUnit = 14.sp) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        SyncDot(state, 8.dp)
        Text(syncLabel(state), color = color, fontSize = fontSize, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun TopBar(title: String, sync: SyncState, onBack: (() -> Unit)?) {
    Surface(color = Color.White, shadowElevation = 1.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .heightIn(min = 58.dp)
                .padding(start = if (onBack != null) 6.dp else 20.dp, end = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Glyph(R.drawable.ic_back, Palette.Ink)
                }
            }
            Text(
                text = title,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = if (onBack != null) 2.dp else 0.dp),
                color = Palette.Ink,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            SyncDot(sync)
        }
    }
}

@Composable
fun Page(
    title: String,
    sync: SyncState,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    head: (@Composable () -> Unit)? = null,
    bottom: (@Composable () -> Unit)? = null,
    scroll: Boolean = true,
    edge: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(modifier.fillMaxSize().background(Palette.Canvas)) {
        TopBar(title, sync, onBack)
        head?.invoke()
        if (scroll) {
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                content()
                if (edge && bottom == null) Spacer(Modifier.navigationBarsPadding())
            }
        } else {
            Column(Modifier.weight(1f).fillMaxWidth()) {
                content()
            }
        }
        bottom?.invoke()
    }
}

enum class BtnKind { Primary, Gold, Tonal, Text, Danger }

@Composable
fun AppButton(
    label: String,
    modifier: Modifier = Modifier,
    kind: BtnKind = BtnKind.Primary,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val container = when (kind) {
        BtnKind.Primary -> Palette.Ink
        BtnKind.Gold -> Palette.Gold
        BtnKind.Tonal -> Palette.Soft
        BtnKind.Text, BtnKind.Danger -> Color.Transparent
    }
    val content = when (kind) {
        BtnKind.Primary -> Color.White
        BtnKind.Gold -> Palette.OnGold
        BtnKind.Tonal -> Palette.Ink
        BtnKind.Text -> Palette.Primary
        BtnKind.Danger -> Palette.Neg
    }
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 54.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = container,
            contentColor = content,
            disabledContainerColor = container.copy(alpha = 0.45f),
            disabledContentColor = content.copy(alpha = 0.6f)
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = 0.dp,
            pressedElevation = 0.dp,
            focusedElevation = 0.dp,
            hoveredElevation = 0.dp,
            disabledElevation = 0.dp
        )
    ) {
        Text(label, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Field(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    keyboard: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Next,
    password: Boolean = false,
    singleLine: Boolean = true,
    minLines: Int = 1,
    placeholder: (@Composable () -> Unit)? = null,
    leading: (@Composable () -> Unit)? = null,
    shape: RoundedCornerShape = RoundedCornerShape(14.dp)
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        label = { Text(label, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        placeholder = placeholder,
        leadingIcon = leading,
        singleLine = singleLine,
        minLines = minLines,
        textStyle = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.Medium),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (password) KeyboardType.Password else keyboard,
            imeAction = imeAction
        ),
        shape = shape,
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Palette.Field,
            focusedBorderColor = Palette.Primary,
            unfocusedBorderColor = Color.Transparent,
            focusedLabelColor = Palette.Primary,
            unfocusedLabelColor = Palette.Muted,
            focusedTextColor = Palette.Text,
            unfocusedTextColor = Palette.Text,
            cursorColor = Palette.Primary,
            focusedPlaceholderColor = Palette.Muted,
            unfocusedPlaceholderColor = Palette.Muted
        )
    )
}

@Composable
fun FieldsBox(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content
    )
}

@Composable
fun Heading(text: String) {
    Row(
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(width = 4.dp, height = 15.dp)
                .background(Palette.Gold, RoundedCornerShape(2.dp))
        )
        Spacer(Modifier.width(8.dp))
        Text(text, color = Palette.Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
fun Hint(text: String) {
    Text(
        text = text,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 10.dp),
        color = Palette.Muted,
        fontSize = 14.sp,
        lineHeight = 23.sp
    )
}

@Composable
fun EmptyNote(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 24.dp, vertical = 36.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Palette.Muted)
    }
}

@Composable
fun NoteBox(text: String) {
    Text(
        text = text,
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        lineHeight = 26.sp
    )
}

@Composable
fun HeadNote(text: String) {
    Text(
        text = text,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 4.dp),
        color = Palette.Muted
    )
}

@Composable
fun Rule() {
    HorizontalDivider(color = Palette.Line, thickness = 1.dp)
}

@Composable
fun GroupBox(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color.White), content = content)
}

@Composable
fun <T> Group(items: List<T>, content: @Composable (T) -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color.White)) {
        items.forEachIndexed { index, item ->
            if (index > 0) Rule()
            content(item)
        }
    }
}

@Composable
fun ActionsBox(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun ListRow(onClick: (() -> Unit)?, content: @Composable RowScope.() -> Unit) {
    val base = Modifier
        .fillMaxWidth()
        .heightIn(min = 66.dp)
    Row(
        modifier = (if (onClick != null) base.clickable(onClick = onClick) else base)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
fun RowScope.TitleBlock(title: String, sub: String?, subColor: Color = Palette.Muted) {
    Column(Modifier.weight(1f)) {
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        if (!sub.isNullOrEmpty()) {
            Text(sub, color = subColor, fontSize = 14.sp)
        }
    }
}

@Composable
fun Chevron() {
    Glyph(R.drawable.ic_chevron, Palette.Chevron, size = 20.dp)
}

@Composable
fun Avatar(name: String) {
    val text = name.trim()
    val letter = if (text.isEmpty()) "•" else String(Character.toChars(text.codePointAt(0)))
    val code = text.sumOf { it.code }
    val (bg, fg) = when (code % 5) {
        0 -> Palette.Soft to Palette.Primary
        1 -> Palette.PosBand to Palette.Pos
        2 -> Palette.OpenBand to Palette.Warn
        3 -> Palette.NegBand to Color(0xFFB02F26)
        else -> Color(0xFFECE4F8) to Color(0xFF5A3AA0)
    }
    Box(
        modifier = Modifier
            .size(44.dp)
            .background(bg, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(letter, color = fg, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

enum class Tone { Amber, Blue, Green, Red, Slate }

@Composable
fun Tile(@DrawableRes icon: Int, tone: Tone) {
    val (bg, fg) = when (tone) {
        Tone.Amber -> Palette.OpenBand to Palette.Warn
        Tone.Blue -> Palette.Soft to Palette.Primary
        Tone.Green -> Palette.PosBand to Palette.Pos
        Tone.Red -> Palette.NegBand to Palette.Neg
        Tone.Slate -> Color(0xFFE8EBF1) to Color(0xFF4B566B)
    }
    Box(
        modifier = Modifier
            .size(46.dp)
            .background(bg, RoundedCornerShape(15.dp)),
        contentAlignment = Alignment.Center
    ) {
        Glyph(icon, fg)
    }
}

@Composable
fun Badge(text: String, paid: Boolean) {
    Box(
        modifier = Modifier
            .background(if (paid) Palette.PosBand else Palette.OpenBand, CircleShape)
            .padding(horizontal = 12.dp, vertical = 3.dp)
    ) {
        Text(
            text = text,
            color = if (paid) Palette.Pos else Palette.OpenText,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

@Composable
fun KvRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 54.dp)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Palette.Muted)
        Spacer(Modifier.width(16.dp))
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    ok: String,
    cancel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(28.dp),
        title = { Text(title, color = Palette.Ink, fontWeight = FontWeight.SemiBold) },
        text = { Text(message, color = Palette.Muted) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(ok, color = Palette.Primary, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(cancel, color = Palette.Primary)
            }
        }
    )
}

@Composable
fun TrashButton(label: String, onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Glyph(R.drawable.ic_trash, Palette.Trash)
    }
}

@Composable
fun FullscreenMessage(text: String) {
    Box(Modifier.fillMaxSize().background(Palette.Canvas), contentAlignment = Alignment.Center) {
        Text(text, color = Palette.Muted)
    }
}
