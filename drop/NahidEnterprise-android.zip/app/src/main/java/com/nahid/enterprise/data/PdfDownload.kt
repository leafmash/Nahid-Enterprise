package com.nahid.enterprise.data

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.nahid.enterprise.R

data class SavedPdf(val uri: Uri, val name: String, val folder: String)

object PdfDownload {

    private const val CHANNEL_ID = "pdf_downloads"
    private const val MIME = "application/pdf"

    fun authority(context: Context): String = "${context.packageName}.files"

    private fun viewIntent(saved: SavedPdf): Intent =
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(saved.uri, MIME)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)

    fun open(context: Context, saved: SavedPdf): Boolean =
        launch(context, viewIntent(saved)) ||
            launch(context, Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    private fun launch(context: Context, intent: Intent): Boolean =
        try {
            context.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            false
        }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(CHANNEL_ID, "PDF ডাউনলোড", NotificationManager.IMPORTANCE_HIGH)
        channel.description = "PDF সেভ সম্পন্ন হলে জানানো হয়"
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun canNotify(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun announce(context: Context, saved: SavedPdf) {
        if (!canNotify(context)) return
        ensureChannel(context)
        val id = saved.uri.hashCode()
        val pending = PendingIntent.getActivity(
            context,
            id,
            viewIntent(saved),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(ContextCompat.getColor(context, R.color.brand))
            .setContentTitle("PDF ডাউনলোড সম্পন্ন")
            .setContentText(saved.name)
            .setStyle(NotificationCompat.BigTextStyle().bigText("${saved.name}\n${saved.folder}"))
            .setSubText("খুলতে ট্যাপ করুন")
            .setContentIntent(pending)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify(id, notification)
    }
}
