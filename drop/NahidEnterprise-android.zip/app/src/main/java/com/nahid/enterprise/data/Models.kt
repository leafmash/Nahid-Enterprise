package com.nahid.enterprise.data

data class Product(val name: String, val rate: Double)

data class ProductLine(
    val product: String,
    val qty: Double,
    val ret: Double,
    val rate: Double,
    val net: Double
)

data class Due(val name: String, val amount: Double, val paid: Boolean)

data class Record(
    val name: String,
    val dest: String,
    val date: String,
    val comment: String,
    val damage: Double,
    val cash: Double,
    val incomplete: Boolean,
    val products: List<ProductLine>,
    val dues: List<Due>,
    val total: Double,
    val finalAmount: Double
)

data class AppState(
    val products: List<Product> = seedProducts(),
    val records: List<Record> = emptyList(),
    val people: List<String> = emptyList()
)

data class Session(val uid: String, val email: String)

enum class SyncState { Synced, Syncing, Pending, Offline }

enum class LoadStatus { None, Pending, Offline, Missing, Loaded, Error }

fun seedProducts(): List<Product> = List(5) { Product("দ্রব্য ${it + 1}", 0.0) }
