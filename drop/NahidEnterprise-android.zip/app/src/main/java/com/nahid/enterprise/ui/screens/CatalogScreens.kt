package com.nahid.enterprise.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nahid.enterprise.AppViewModel
import com.nahid.enterprise.data.Product
import com.nahid.enterprise.ui.ActionsBox
import com.nahid.enterprise.ui.AppButton
import com.nahid.enterprise.ui.Avatar
import com.nahid.enterprise.ui.BtnKind
import com.nahid.enterprise.ui.ConfirmDialog
import com.nahid.enterprise.ui.EmptyNote
import com.nahid.enterprise.ui.Field
import com.nahid.enterprise.ui.FieldsBox
import com.nahid.enterprise.ui.Group
import com.nahid.enterprise.ui.GroupBox
import com.nahid.enterprise.ui.HeadNote
import com.nahid.enterprise.ui.Heading
import com.nahid.enterprise.ui.Hint
import com.nahid.enterprise.ui.ListRow
import com.nahid.enterprise.ui.Notifier
import com.nahid.enterprise.ui.Page
import com.nahid.enterprise.ui.Palette
import com.nahid.enterprise.ui.Rule
import com.nahid.enterprise.ui.TitleBlock
import com.nahid.enterprise.ui.TrashButton
import com.nahid.enterprise.util.fmt
import com.nahid.enterprise.util.num
import com.nahid.enterprise.util.parseOrNull
import com.nahid.enterprise.util.taka
import com.nahid.enterprise.util.toLatinDigits
import java.util.concurrent.atomic.AtomicLong

private class ProductRow(val id: Long, name: String, rate: String) {
    var name by mutableStateOf(name)
    var rate by mutableStateOf(rate)
    val focus = FocusRequester()
    var autoFocus = false
}

private val bulkPrimary = Regex("^(.+?)\\s*[-–—:=\\t]\\s*(?=\\d)(.+)\$")
private val bulkSecondary = Regex("^(.+?)\\s{2,}(.+)\$")
private val rateJunk = Regex("[^0-9.\\-]")

private fun parseBulk(text: String): List<Product> {
    val out = ArrayList<Product>()
    toLatinDigits(text).split(Regex("\\r?\\n")).forEach { line ->
        val s = line.trim()
        if (s.isEmpty()) return@forEach
        val match = bulkPrimary.find(s) ?: bulkSecondary.find(s) ?: return@forEach
        val name = match.groupValues[1].trim()
        val rate = parseOrNull(match.groupValues[2].replace(rateJunk, ""))
        if (name.isNotEmpty() && rate != null) out.add(Product(name, rate))
    }
    return out
}

private fun productSnapshot(rows: List<ProductRow>): String =
    rows.joinToString("\u0003") { "${it.name.trim()}|${num(it.rate)}" }

private fun toRows(ids: AtomicLong, products: List<Product>): List<ProductRow> =
    products.map { ProductRow(ids.incrementAndGet(), it.name, if (it.rate != 0.0) fmt(it.rate) else "") }

private fun focusRow(requester: FocusRequester) {
    try {
        requester.requestFocus()
    } catch (e: Exception) {
        return
    }
}

@Composable
private fun ProductBlock(row: ProductRow, onRemove: () -> Unit) {
    LaunchedEffect(row) {
        if (row.autoFocus) {
            row.autoFocus = false
            focusRow(row.focus)
        }
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Field(
            value = row.name,
            onValueChange = { row.name = it },
            label = "দ্রব্যের নাম",
            modifier = Modifier
                .weight(1.5f)
                .focusRequester(row.focus),
            placeholder = { Text("যেমন: চাল") }
        )
        Field(
            value = row.rate,
            onValueChange = { row.rate = it },
            label = "দর (৳)",
            modifier = Modifier.weight(1f),
            keyboard = KeyboardType.Decimal
        )
        TrashButton("এই দ্রব্য বাদ দিন", onRemove)
    }
}

@Composable
fun ProductsScreen(vm: AppViewModel, notify: Notifier) {
    val state by vm.appState.collectAsState()
    val sync by vm.syncState.collectAsState()
    val ids = remember { AtomicLong(0) }
    val rows = remember {
        mutableStateListOf<ProductRow>().apply { addAll(toRows(ids, vm.store.state.value.products)) }
    }
    var initial by remember { mutableStateOf(productSnapshot(rows)) }
    var bulk by remember { mutableStateOf("") }
    var showLeave by remember { mutableStateOf(false) }

    fun requestBack() {
        if (productSnapshot(rows) != initial) showLeave = true else vm.back()
    }

    BackHandler(enabled = true) { requestBack() }

    fun reload(products: List<Product>) {
        rows.clear()
        rows.addAll(toRows(ids, products))
        initial = productSnapshot(rows)
    }

    fun removeRow(row: ProductRow) {
        val at = rows.indexOf(row)
        if (at < 0) return
        rows.removeAt(at)
        val label = row.name.trim().ifEmpty { "দ্রব্য" }
        notify.show("$label তালিকা থেকে বাদ হয়েছে — Save করলে স্থায়ী হবে", "ফিরিয়ে আনুন") {
            rows.add(minOf(at, rows.size), row)
        }
    }

    fun save() {
        val filled = rows.filter { it.name.trim().isNotEmpty() || num(it.rate) != 0.0 }
        val nameless = filled.firstOrNull { it.name.trim().isEmpty() }
        if (nameless != null) {
            notify.show("দ্রব্যের নাম লিখুন")
            focusRow(nameless.focus)
            return
        }
        val items = filled.map { Product(it.name.trim(), num(it.rate)) }
        if (items.isEmpty()) {
            notify.show("কমপক্ষে একটি দ্রব্য রাখুন")
            return
        }
        val names = items.map { it.name.lowercase() }
        val dupAt = names.indices.firstOrNull { names.indexOf(names[it]) != it }
        if (dupAt != null) {
            notify.show("\"${items[dupAt].name}\" দুইবার আছে")
            focusRow(filled[dupAt].focus)
            return
        }
        vm.replaceProducts(items)
        notify.show("দ্রব্য Save হয়েছে")
        reload(items)
    }

    fun paste() {
        val parsed = parseBulk(bulk)
        if (parsed.isEmpty()) {
            notify.show("কোনো দ্রব্য পড়া যায়নি। প্রতি লাইনে \"নাম - দর\" লিখুন")
            return
        }
        vm.upsertProducts(parsed)
        notify.show("${parsed.size}টি দ্রব্য একসাথে Save হয়েছে")
        bulk = ""
        reload(vm.store.state.value.products)
    }

    Page(
        title = "দ্রব্যের নাম ও দর",
        sync = sync,
        onBack = { requestBack() },
        scrollState = vm.scrollState("products"),
        head = { HeadNote("মোট ${state.products.size}টি দ্রব্য") }
    ) {
        Hint("নাম ও দর বদলে নিচের Save চাপুন। পুরোনো হিসাবের দর অপরিবর্তিত থাকবে।")
        Spacer(Modifier.height(10.dp))
        GroupBox {
            rows.toList().forEachIndexed { position, row ->
                if (position > 0) Rule()
                key(row.id) { ProductBlock(row) { removeRow(row) } }
            }
            if (rows.isNotEmpty()) Rule()
            AddRow("নতুন দ্রব্য যোগ করুন") {
                val row = ProductRow(ids.incrementAndGet(), "", "")
                row.autoFocus = true
                rows.add(row)
            }
        }
        ActionsBox {
            AppButton("Save") { save() }
        }
        Heading("একসাথে অনেক দ্রব্য Paste করুন")
        FieldsBox {
            Field(
                value = bulk,
                onValueChange = { bulk = it },
                label = "নাম - দর",
                singleLine = false,
                minLines = 6,
                placeholder = { Text("যেমন: চাল - ৫০\nডাল - ৮০\nতেল - ১৬৫") }
            )
        }
        Hint("প্রতি লাইনে: দ্রব্যের নাম - দর   |   Tab / : / = দিয়েও লেখা যাবে")
        ActionsBox {
            AppButton("Paste করে একবারে Save", kind = BtnKind.Tonal) { paste() }
        }
    }

    if (showLeave) {
        ConfirmDialog(
            title = "বের হবেন?",
            message = "Save না করা পরিবর্তন মুছে যাবে।",
            ok = "বের হন",
            cancel = "থাকুন",
            onConfirm = {
                showLeave = false
                vm.back()
            },
            onDismiss = { showLeave = false }
        )
    }
}

@Composable
fun DuesScreen(vm: AppViewModel, notify: Notifier) {
    val state by vm.appState.collectAsState()
    val sync by vm.syncState.collectAsState()
    var person by remember { mutableStateOf("") }

    val totals = LinkedHashMap<String, Double>()
    state.records.forEach { rec ->
        rec.dues.forEach { due ->
            val name = due.name.trim()
            if (name.isNotEmpty() && !due.paid) totals[name] = (totals[name] ?: 0.0) + due.amount
        }
    }
    val owed = totals.entries.map { it.key to it.value }.sortedByDescending { it.second }
    val sum = owed.sumOf { it.second }
    val saved = state.people.withIndex().toList()

    fun addPerson() {
        val value = person.trim()
        if (value.isEmpty()) {
            notify.show("ব্যক্তির নাম লিখুন")
            return
        }
        if (state.people.contains(value)) {
            notify.show("এই নাম আগে থেকেই আছে")
            return
        }
        vm.replacePeople(state.people + value)
        notify.show("$value তালিকায় যোগ হয়েছে")
        person = ""
    }

    fun removePerson(name: String, at: Int) {
        vm.replacePeople(state.people.filterIndexed { i, _ -> i != at })
        notify.show("$name তালিকা থেকে বাদ হয়েছে", "ফিরিয়ে আনুন") {
            val now = vm.store.state.value.people
            val position = minOf(at, now.size)
            vm.replacePeople(now.take(position) + name + now.drop(position))
        }
    }

    Page(
        title = "বাকি ব্যক্তির তালিকা",
        sync = sync,
        onBack = null,
        edge = false,
        scrollState = vm.scrollState("dues"),
        head = {
            HeroHead(
                title = "মোট বাকি",
                sub = if (owed.isNotEmpty()) "${owed.size} জনের কাছে বাকি আছে" else "এখন কোনো বাকি নেই",
                bandLabel = "মোট",
                bandBg = Palette.OpenBand,
                bandFg = Palette.OpenText
            ) {
                Text(taka(sum), color = Palette.OpenText, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }
        }
    ) {
        Heading("যাদের কাছে বাকি আছে")
        if (owed.isEmpty()) {
            EmptyNote("এখন কোনো বাকি নেই।")
        } else {
            Group(owed) { entry ->
                ListRow(null) {
                    Avatar(entry.first)
                    TitleBlock(entry.first, null)
                    Text(taka(entry.second), color = Palette.Warn, fontWeight = FontWeight.Bold)
                }
            }
        }
        Heading("সংরক্ষিত ব্যক্তি")
        Hint("এই নামগুলো নতুন হিসাবের বাকি অংশে বেছে নেওয়া যাবে।")
        if (saved.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Group(saved) { item ->
                val name = item.value
                ListRow(null) {
                    Avatar(name)
                    TitleBlock(
                        name,
                        if (totals.containsKey(name)) "বাকি " + taka(totals.getValue(name)) else null,
                        Palette.Warn
                    )
                    TrashButton("$name বাদ দিন") { removePerson(name, item.index) }
                }
            }
        }
        FieldsBox {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Field(
                    value = person,
                    onValueChange = { person = it },
                    label = "ব্যক্তির নাম",
                    modifier = Modifier.weight(1f)
                )
                AppButton("যোগ", modifier = Modifier.width(96.dp)) { addPerson() }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
