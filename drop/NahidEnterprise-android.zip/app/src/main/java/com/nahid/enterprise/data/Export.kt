package com.nahid.enterprise.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import com.nahid.enterprise.util.fmt
import java.io.ByteArrayOutputStream
import java.io.File

object Export {

    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val MARGIN = 36f
    private const val CONTENT_W = PAGE_W - 2 * MARGIN
    private const val BOTTOM = 58f

    private const val INK = 0xFF0B2A55.toInt()
    private const val PRIMARY = 0xFF2456A4.toInt()
    private const val GOLD = 0xFFF2B72B.toInt()
    private const val GOLD_LIGHT = 0xFFFFD36B.toInt()
    private const val SOFT = 0xFFE4EDFC.toInt()
    private const val FIELD = 0xFFF4F7FC.toInt()
    private const val LINE = 0xFFE3E9F3.toInt()
    private const val MUTED = 0xFF68738A.toInt()
    private const val TEXT = 0xFF131A26.toInt()
    private const val POS = 0xFF0B7A52.toInt()
    private const val POS_BAND = 0xFFDDF5EA.toInt()
    private const val NEG = 0xFFC9382E.toInt()
    private const val NEG_BAND = 0xFFFDE8E5.toInt()
    private const val OPEN_BAND = 0xFFFFF1CF.toInt()
    private const val OPEN_TEXT = 0xFF7A5200.toInt()
    private const val TILE = 0xFFF3F6FC.toInt()

    private fun textPaint(
        color: Int,
        size: Float,
        bold: Boolean = false,
        align: Paint.Align = Paint.Align.LEFT,
        face: Typeface? = null
    ): TextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        textSize = size
        textAlign = align
        typeface = face ?: if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun fillPaint(color: Int): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        style = Paint.Style.FILL
    }

    private fun fit(text: String, paint: TextPaint, width: Float): String =
        TextUtils.ellipsize(text, paint, width, TextUtils.TruncateAt.END).toString()

    private fun money(value: Double): String = "৳" + fmt(value)

    private class Sheet(val doc: PdfDocument, val record: Record) {
        var number = 0
        lateinit var page: PdfDocument.Page
        lateinit var canvas: Canvas
        var y = 0f

        fun begin() {
            number++
            page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, number).create())
            canvas = page.canvas
            if (number == 1) coverHeader() else slimHeader()
        }

        fun end() {
            footer()
            doc.finishPage(page)
        }

        fun ensure(height: Float, again: (() -> Unit)? = null) {
            if (y + height > PAGE_H - BOTTOM) {
                end()
                begin()
                again?.invoke()
            }
        }

        private fun logoTile(x: Float, top: Float, size: Float) {
            val k = size / 200f
            canvas.drawRoundRect(x, top, x + size, top + size, 46f * k, 46f * k, fillPaint(TILE))
            canvas.drawRoundRect(
                x + 30f * k, top + 34f * k, x + 170f * k, top + 166f * k,
                30f * k, 30f * k, fillPaint(INK)
            )
            val letters = textPaint(0xFFFFFFFF.toInt(), 78f * k, true, Paint.Align.CENTER, Typeface.SERIF)
            canvas.drawText("NE", x + 100f * k, top + 116f * k, letters)
            canvas.drawRoundRect(
                x + 56f * k, top + 130f * k, x + 144f * k, top + 138f * k,
                4f * k, 4f * k, fillPaint(GOLD)
            )
        }

        private fun coverHeader() {
            val band = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    0f, 0f, PAGE_W.toFloat(), 150f,
                    intArrayOf(0xFF0A2750.toInt(), 0xFF1B4C97.toInt(), 0xFF2A62B8.toInt()),
                    null,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRoundRect(0f, -40f, PAGE_W.toFloat(), 142f, 34f, 34f, band)
            val glow = fillPaint(0x14FFFFFF)
            canvas.drawCircle(PAGE_W - 40f, 10f, 110f, glow)
            canvas.drawCircle(30f, 150f, 70f, fillPaint(0x0FFFFFFF))
            logoTile(MARGIN, 36f, 62f)
            canvas.drawText(
                "Nahid Enterprise",
                MARGIN + 80f, 68f,
                textPaint(0xFFFFFFFF.toInt(), 25f, true)
            )
            canvas.drawRoundRect(MARGIN + 80f, 78f, MARGIN + 126f, 82f, 2f, 2f, fillPaint(GOLD))
            canvas.drawText(
                fit("প্রো: মো আবু তালেব • দৈনিক ব্যবসার হিসাব", textPaint(0xFFFFFFFF.toInt(), 10.5f), 300f),
                MARGIN + 80f, 100f,
                textPaint(0xCCFFFFFF.toInt(), 10.5f)
            )
            canvas.drawText(
                "হিসাব বিবরণী",
                PAGE_W - MARGIN, 62f,
                textPaint(GOLD_LIGHT, 15f, true, Paint.Align.RIGHT)
            )
            canvas.drawText(
                record.date,
                PAGE_W - MARGIN, 82f,
                textPaint(0xE6FFFFFF.toInt(), 11f, false, Paint.Align.RIGHT)
            )
            y = 172f
        }

        private fun slimHeader() {
            val band = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    0f, 0f, PAGE_W.toFloat(), 0f,
                    intArrayOf(0xFF0A2750.toInt(), 0xFF2A62B8.toInt()),
                    null,
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawRoundRect(0f, -30f, PAGE_W.toFloat(), 48f, 22f, 22f, band)
            canvas.drawText(
                "Nahid Enterprise",
                MARGIN, 30f,
                textPaint(0xFFFFFFFF.toInt(), 14f, true)
            )
            canvas.drawText(
                fit(record.name.ifEmpty { "—" } + " • " + record.date, textPaint(GOLD_LIGHT, 11f), 260f),
                PAGE_W - MARGIN, 30f,
                textPaint(GOLD_LIGHT, 11f, false, Paint.Align.RIGHT)
            )
            y = 74f
        }

        private fun footer() {
            val base = PAGE_H - 30f
            canvas.drawRect(MARGIN, base - 16f, PAGE_W - MARGIN, base - 15f, fillPaint(LINE))
            canvas.drawText(
                "Nahid Enterprise • প্রো: মো আবু তালেব",
                MARGIN, base,
                textPaint(MUTED, 8.5f)
            )
            canvas.drawText(
                "পৃষ্ঠা $number",
                PAGE_W - MARGIN, base,
                textPaint(MUTED, 8.5f, false, Paint.Align.RIGHT)
            )
        }

        fun section(title: String) {
            ensure(44f)
            y += 22f
            canvas.drawCircle(MARGIN + 4f, y - 4.5f, 4f, fillPaint(GOLD))
            canvas.drawText(title, MARGIN + 16f, y, textPaint(INK, 13.5f, true))
            y += 12f
        }

        fun infoCards() {
            val gap = 10f
            val w = (CONTENT_W - 2 * gap) / 3f
            val items = listOf(
                "নাম" to record.name.ifEmpty { "—" },
                "গন্তব্য" to record.dest.ifEmpty { "—" },
                "তারিখ" to record.date.ifEmpty { "—" }
            )
            items.forEachIndexed { i, item ->
                val x = MARGIN + i * (w + gap)
                canvas.drawRoundRect(x, y, x + w, y + 54f, 14f, 14f, fillPaint(FIELD))
                canvas.drawRoundRect(x, y + 12f, x + 3.5f, y + 42f, 2f, 2f, fillPaint(GOLD))
                canvas.drawText(item.first, x + 14f, y + 21f, textPaint(MUTED, 9f))
                val value = textPaint(INK, 12.5f, true)
                canvas.drawText(fit(item.second, value, w - 24f), x + 14f, y + 40f, value)
            }
            y += 54f
        }

        private val colName = MARGIN + 12f
        private val colQty = PAGE_W - MARGIN - 218f
        private val colRet = PAGE_W - MARGIN - 156f
        private val colRate = PAGE_W - MARGIN - 94f
        private val colNet = PAGE_W - MARGIN - 12f

        private fun productHead() {
            canvas.drawRoundRect(MARGIN, y, PAGE_W - MARGIN, y + 28f, 10f, 10f, fillPaint(INK))
            val h = textPaint(0xFFFFFFFF.toInt(), 9.5f, true)
            val hr = textPaint(0xFFFFFFFF.toInt(), 9.5f, true, Paint.Align.RIGHT)
            canvas.drawText("দ্রব্য", colName, y + 18f, h)
            canvas.drawText("পরিমাণ", colQty, y + 18f, hr)
            canvas.drawText("ফেরত", colRet, y + 18f, hr)
            canvas.drawText("দর", colRate, y + 18f, hr)
            canvas.drawText("নিট বিক্রি", colNet, y + 18f, hr)
            y += 28f
        }

        fun products() {
            ensure(28f + 28f)
            productHead()
            if (record.products.isEmpty()) {
                canvas.drawRect(MARGIN, y, PAGE_W - MARGIN, y + 30f, fillPaint(FIELD))
                canvas.drawText("কোনো দ্রব্য নেই", colName, y + 19f, textPaint(MUTED, 10.5f))
                y += 30f
            }
            record.products.forEachIndexed { i, x ->
                ensure(28f) { productHead() }
                if (i % 2 == 1) canvas.drawRect(MARGIN, y, PAGE_W - MARGIN, y + 28f, fillPaint(FIELD))
                val right = textPaint(TEXT, 10.5f, false, Paint.Align.RIGHT)
                canvas.drawText(fit(x.product, textPaint(INK, 10.5f, true), colQty - colName - 60f), colName, y + 18f, textPaint(INK, 10.5f, true))
                canvas.drawText(fmt(x.qty), colQty, y + 18f, right)
                canvas.drawText(fmt(x.ret), colRet, y + 18f, right)
                canvas.drawText(money(x.rate), colRate, y + 18f, right)
                canvas.drawText(money(x.net), colNet, y + 18f, textPaint(PRIMARY, 10.5f, true, Paint.Align.RIGHT))
                y += 28f
            }
            canvas.drawRect(MARGIN, y, PAGE_W - MARGIN, y + 1.2f, fillPaint(LINE))
            y += 1.2f
        }

        fun summaryCards() {
            ensure(70f)
            val gap = 10f
            val w = (CONTENT_W - 2 * gap) / 3f
            val items = listOf(
                Triple("মোট নিট বিক্রি", money(record.total), SOFT to INK),
                Triple("ডেমেজ", money(record.damage), NEG_BAND to NEG),
                Triple("হ্যান্ড ক্যাশ", money(record.cash), OPEN_BAND to OPEN_TEXT)
            )
            items.forEachIndexed { i, item ->
                val x = MARGIN + i * (w + gap)
                canvas.drawRoundRect(x, y, x + w, y + 62f, 16f, 16f, fillPaint(item.third.first))
                canvas.drawText(item.first, x + 14f, y + 22f, textPaint(item.third.second, 9.5f, false))
                val value = textPaint(item.third.second, 17f, true)
                canvas.drawText(fit(item.second, value, w - 28f), x + 14f, y + 47f, value)
            }
            y += 62f
        }

        private fun dueHead() {
            canvas.drawRoundRect(MARGIN, y, PAGE_W - MARGIN, y + 26f, 10f, 10f, fillPaint(INK))
            val h = textPaint(0xFFFFFFFF.toInt(), 9.5f, true)
            canvas.drawText("ব্যক্তি", colName, y + 17f, h)
            canvas.drawText("টাকা", colRate, y + 17f, textPaint(0xFFFFFFFF.toInt(), 9.5f, true, Paint.Align.RIGHT))
            canvas.drawText("অবস্থা", colNet - 22f, y + 17f, textPaint(0xFFFFFFFF.toInt(), 9.5f, true, Paint.Align.CENTER))
            y += 26f
        }

        fun dues() {
            if (record.dues.isEmpty()) {
                ensure(34f)
                canvas.drawRoundRect(MARGIN, y, PAGE_W - MARGIN, y + 34f, 12f, 12f, fillPaint(FIELD))
                canvas.drawText("কোনো বাকি নেই", colName, y + 21f, textPaint(MUTED, 10.5f))
                y += 34f
                return
            }
            ensure(26f + 30f)
            dueHead()
            record.dues.forEachIndexed { i, x ->
                ensure(30f) { dueHead() }
                if (i % 2 == 1) canvas.drawRect(MARGIN, y, PAGE_W - MARGIN, y + 30f, fillPaint(FIELD))
                val name = textPaint(INK, 10.5f, true)
                canvas.drawText(fit(x.name, name, colRate - colName - 90f), colName, y + 19f, name)
                canvas.drawText(money(x.amount), colRate, y + 19f, textPaint(TEXT, 10.5f, false, Paint.Align.RIGHT))
                val pillW = 54f
                val pillX = colNet - 22f - pillW / 2f
                val bg = if (x.paid) POS_BAND else OPEN_BAND
                val fg = if (x.paid) POS else OPEN_TEXT
                canvas.drawRoundRect(pillX, y + 7f, pillX + pillW, y + 23f, 8f, 8f, fillPaint(bg))
                canvas.drawText(
                    if (x.paid) "PAID" else "বাকি",
                    pillX + pillW / 2f, y + 18.5f,
                    textPaint(fg, 8.5f, true, Paint.Align.CENTER)
                )
                y += 30f
            }
            canvas.drawRect(MARGIN, y, PAGE_W - MARGIN, y + 1.2f, fillPaint(LINE))
            y += 1.2f
        }

        fun comment() {
            if (record.comment.isBlank()) return
            section("মন্তব্য")
            val paint = textPaint(TEXT, 11f)
            val width = (CONTENT_W - 32f).toInt()
            val layout = StaticLayout.Builder
                .obtain(record.comment, 0, record.comment.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(3f, 1f)
                .build()
            val height = layout.height + 28f
            ensure(height)
            canvas.drawRoundRect(MARGIN, y, PAGE_W - MARGIN, y + height, 14f, 14f, fillPaint(FIELD))
            canvas.drawRoundRect(MARGIN, y + 10f, MARGIN + 3.5f, y + height - 10f, 2f, 2f, fillPaint(GOLD))
            canvas.save()
            canvas.translate(MARGIN + 16f, y + 14f)
            layout.draw(canvas)
            canvas.restore()
            y += height
        }

        fun finalBand() {
            ensure(96f)
            y += 26f
            val positive = record.finalAmount >= 0
            val color = if (positive) POS else NEG
            canvas.drawRoundRect(MARGIN, y, PAGE_W - MARGIN, y + 72f, 20f, 20f, fillPaint(color))
            canvas.drawCircle(PAGE_W - MARGIN - 20f, y + 8f, 60f, fillPaint(0x1AFFFFFF))
            canvas.drawRoundRect(MARGIN + 18f, y + 22f, MARGIN + 22f, y + 50f, 2f, 2f, fillPaint(GOLD_LIGHT))
            canvas.drawText("চূড়ান্ত হিসাব", MARGIN + 34f, y + 33f, textPaint(0xFFFFFFFF.toInt(), 14f, true))
            canvas.drawText(
                if (positive) "লাভ / জমা" else "ঘাটতি",
                MARGIN + 34f, y + 52f,
                textPaint(0xCCFFFFFF.toInt(), 9.5f)
            )
            canvas.drawText(
                money(record.finalAmount),
                PAGE_W - MARGIN - 22f, y + 46f,
                textPaint(0xFFFFFFFF.toInt(), 28f, true, Paint.Align.RIGHT)
            )
            y += 72f
        }
    }

    fun pdfBytes(record: Record): ByteArray {
        val doc = PdfDocument()
        try {
            val sheet = Sheet(doc, record)
            sheet.begin()
            sheet.infoCards()
            sheet.section("দ্রব্যের হিসাব")
            sheet.products()
            sheet.section("হিসাব")
            sheet.summaryCards()
            sheet.section("বাকির হিসাব")
            sheet.dues()
            sheet.comment()
            sheet.finalBand()
            sheet.end()
            val out = ByteArrayOutputStream()
            doc.writeTo(out)
            return out.toByteArray()
        } finally {
            doc.close()
        }
    }

    fun fileName(o: Record): String {
        val date = o.date.ifEmpty { "date" }
        val name = o.name.ifEmpty { "hisab" }
        val raw = "${date}_$name".replace(Regex("[^\\p{L}\\p{N}_-]+"), "_")
        return "Nahid_Enterprise_$raw.pdf"
    }

    fun saveToPhone(context: Context, rec: Record): Boolean {
        return try {
            val name = fileName(rec)
            val bytes = pdfBytes(rec)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Nahid Enterprise")
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
                val stream = resolver.openOutputStream(uri) ?: return false
                stream.use { it.write(bytes) }
                true
            } else {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: return false
                dir.mkdirs()
                File(dir, name).writeBytes(bytes)
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
