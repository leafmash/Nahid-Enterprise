package com.nahid.enterprise.data

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.nahid.enterprise.util.fmt
import java.io.File

object Export {

    fun recordText(o: Record): String {
        val lines = ArrayList<String>()
        lines.add("Nahid Enterprise")
        lines.add("প্রো: মো আবু তালেব")
        lines.add("==============================")
        lines.add("নাম: ${o.name}")
        lines.add("গন্তব্য: ${o.dest}")
        lines.add("তারিখ: ${o.date}")
        lines.add("")
        lines.add("দ্রব্য | পরিমাণ | ফেরত | দর | নিট বিক্রি")
        o.products.forEach { x ->
            lines.add("${x.product} | ${fmt(x.qty)} | ${fmt(x.ret)} | ৳${fmt(x.rate)} | ৳${fmt(x.net)}")
        }
        lines.add("")
        lines.add("মোট নিট বিক্রি: ৳${fmt(o.total)}")
        lines.add("ডেমেজ: ৳${fmt(o.damage)}")
        lines.add("হ্যান্ড ক্যাশ: ৳${fmt(o.cash)}")
        lines.add("বাকি:")
        o.dues.forEach { x ->
            lines.add("${x.name} — ৳${fmt(x.amount)}${if (x.paid) " (PAID)" else " (বাকি)"}")
        }
        lines.add("")
        lines.add("চূড়ান্ত হিসাব: ৳${fmt(o.finalAmount)}")
        lines.add("মন্তব্য: ${o.comment}")
        lines.add("")
        return lines.joinToString("\n")
    }

    fun fileName(o: Record): String {
        val date = o.date.ifEmpty { "date" }
        val name = o.name.ifEmpty { "hisab" }
        val raw = "${date}_$name".replace(Regex("[^\\p{L}\\p{N}_-]+"), "_")
        return "Nahid_Enterprise_$raw.txt"
    }

    fun saveToPhone(context: Context, rec: Record): Boolean {
        return try {
            val name = fileName(rec)
            val bytes = recordText(rec).toByteArray(Charsets.UTF_8)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Nahid Enterprise")
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
                val stream = resolver.openOutputStream(uri) ?: return false
                stream.use { it.write(bytes) }
                true
            } else {
                val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: return false
                dir.mkdirs()
                File(dir, name).writeBytes(bytes)
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
