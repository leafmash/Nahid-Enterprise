package com.nahid.enterprise.data

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.floor

object Codec {

    private fun number(value: Double): Any =
        if (value == floor(value) && abs(value) < 1e15) value.toLong() else value

    private fun text(o: JSONObject, key: String): String =
        if (o.isNull(key)) "" else o.optString(key, "")

    private fun decimal(o: JSONObject, key: String): Double {
        val v = o.optDouble(key, 0.0)
        return if (v.isNaN() || v.isInfinite()) 0.0 else v
    }

    private fun <T> objects(array: JSONArray?, read: (JSONObject) -> T): List<T> {
        if (array == null) return emptyList()
        val out = ArrayList<T>(array.length())
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            out.add(read(item))
        }
        return out
    }

    fun parseArray(source: String?): JSONArray? {
        if (source.isNullOrBlank()) return null
        return try {
            JSONArray(source)
        } catch (e: Exception) {
            null
        }
    }

    fun lineToJson(line: ProductLine): JSONObject = JSONObject()
        .put("product", line.product)
        .put("qty", number(line.qty))
        .put("ret", number(line.ret))
        .put("rate", number(line.rate))
        .put("net", number(line.net))

    fun lineFromJson(o: JSONObject): ProductLine = ProductLine(
        product = text(o, "product"),
        qty = decimal(o, "qty"),
        ret = decimal(o, "ret"),
        rate = decimal(o, "rate"),
        net = decimal(o, "net")
    )

    fun dueToJson(due: Due): JSONObject = JSONObject()
        .put("name", due.name)
        .put("amount", number(due.amount))
        .put("paid", due.paid)

    fun dueFromJson(o: JSONObject): Due = Due(
        name = text(o, "name"),
        amount = decimal(o, "amount"),
        paid = o.optBoolean("paid", false)
    )

    fun recordToJson(rec: Record): JSONObject {
        val lines = JSONArray()
        rec.products.forEach { lines.put(lineToJson(it)) }
        val dues = JSONArray()
        rec.dues.forEach { dues.put(dueToJson(it)) }
        return JSONObject()
            .put("name", rec.name)
            .put("dest", rec.dest)
            .put("date", rec.date)
            .put("comment", rec.comment)
            .put("damage", number(rec.damage))
            .put("cash", number(rec.cash))
            .put("incomplete", rec.incomplete)
            .put("products", lines)
            .put("dues", dues)
            .put("total", number(rec.total))
            .put("final", number(rec.finalAmount))
    }

    fun recordFromJson(o: JSONObject): Record = Record(
        name = text(o, "name"),
        dest = text(o, "dest"),
        date = text(o, "date"),
        comment = text(o, "comment"),
        damage = decimal(o, "damage"),
        cash = decimal(o, "cash"),
        incomplete = o.optBoolean("incomplete", false),
        products = objects(o.optJSONArray("products")) { lineFromJson(it) },
        dues = objects(o.optJSONArray("dues")) { dueFromJson(it) },
        total = decimal(o, "total"),
        finalAmount = decimal(o, "final")
    )

    fun recordsToArray(records: List<Record>): JSONArray {
        val array = JSONArray()
        records.forEach { array.put(recordToJson(it)) }
        return array
    }

    fun recordsFromArray(array: JSONArray?): List<Record> = objects(array) { recordFromJson(it) }

    fun stringsToArray(items: List<String>): JSONArray {
        val array = JSONArray()
        items.forEach { array.put(it) }
        return array
    }

    fun stringsFromArray(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        val out = ArrayList<String>(array.length())
        for (i in 0 until array.length()) {
            if (!array.isNull(i)) out.add(array.optString(i, ""))
        }
        return out
    }

    fun ratesToArray(products: List<Product>): JSONArray {
        val array = JSONArray()
        products.forEach { array.put(number(it.rate)) }
        return array
    }

    fun productsToLocal(products: List<Product>): JSONArray {
        val array = JSONArray()
        products.forEach {
            array.put(JSONObject().put("name", it.name).put("rate", number(it.rate)))
        }
        return array
    }

    fun productsFromLocal(array: JSONArray?): List<Product> =
        objects(array) { Product(text(it, "name"), decimal(it, "rate")) }
}
