package com.nahid.enterprise.util

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val leadingNumber = Regex("^[+-]?(\\d+\\.?\\d*|\\.\\d+)")

fun toLatinDigits(text: String): String = buildString(text.length) {
    for (ch in text) {
        if (ch in '০'..'৯') append('0' + (ch - '০')) else append(ch)
    }
}

fun parseOrNull(value: String): Double? {
    val cleaned = toLatinDigits(value).trim()
    val match = leadingNumber.find(cleaned) ?: return null
    val parsed = match.value.toDoubleOrNull() ?: return null
    return if (parsed.isNaN() || parsed.isInfinite()) null else parsed
}

fun num(value: String): Double = parseOrNull(value) ?: 0.0

fun fmt(value: Double): String {
    if (value.isNaN() || value.isInfinite()) return "0"
    return BigDecimal.valueOf(value)
        .setScale(2, RoundingMode.HALF_UP)
        .stripTrailingZeros()
        .toPlainString()
}

fun taka(value: Double): String = "৳" + fmt(value)

fun today(): String = dateKey(0)

fun dateKey(daysAgo: Int): String {
    val calendar = Calendar.getInstance()
    calendar.add(Calendar.DAY_OF_YEAR, -daysAgo)
    return SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date(calendar.timeInMillis))
}

fun dayOfMonth(daysAgo: Int): String {
    val calendar = Calendar.getInstance()
    calendar.add(Calendar.DAY_OF_YEAR, -daysAgo)
    return calendar.get(Calendar.DAY_OF_MONTH).toString()
}
