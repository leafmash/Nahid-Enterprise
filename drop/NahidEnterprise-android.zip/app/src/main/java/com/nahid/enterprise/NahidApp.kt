package com.nahid.enterprise

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

class NahidApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (FirebaseApp.getApps(this).isEmpty()) {
            val options = FirebaseOptions.Builder()
                .setApiKey(BuildConfigValues.API_KEY)
                .setApplicationId(BuildConfigValues.APP_ID)
                .setProjectId(BuildConfigValues.PROJECT_ID)
                .setStorageBucket(BuildConfigValues.STORAGE_BUCKET)
                .setGcmSenderId(BuildConfigValues.SENDER_ID)
                .build()
            FirebaseApp.initializeApp(this, options)
        }
    }
}

object BuildConfigValues {
    const val API_KEY = "AIzaSyD6ZPpogBpC6rmG3EdihLBzI-_-9bO0M00"
    const val APP_ID = "1:630661999676:web:d00eda1ee25034c52fe739"
    const val PROJECT_ID = "dokan-c7c1e"
    const val STORAGE_BUCKET = "dokan-c7c1e.firebasestorage.app"
    const val SENDER_ID = "630661999676"
}
