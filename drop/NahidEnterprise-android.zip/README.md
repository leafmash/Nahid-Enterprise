# Nahid Enterprise — Native Android (Kotlin + Jetpack Compose)

ওয়েব অ্যাপের সম্পূর্ণ নেটিভ রূপ। কোনো WebView নেই; UI পুরোটাই Jetpack Compose (Material 3)।

## ডেটা
ওয়েব অ্যাপের মতোই Firebase Auth (Email/Password) ও Firestore `users/{uid}` ডকুমেন্ট (products, rates, records, people) ব্যবহার হয়। একই Account দিয়ে Login করলে পুরোনো সব হিসাব দেখা যাবে। অফলাইনে লোকালি সেভ হয়, নেটওয়ার্ক এলে নিজে থেকে সিংক হয়।

## APK তৈরি (GitHub Actions)
1. রিপোজিটরির `main` ব্রাঞ্চে push করুন।
2. Actions ট্যাবে `Android Build` চলবে; শেষে Artifacts থেকে `NahidEnterprise-apk` ডাউনলোড করুন।
3. `v1.0.0` এর মতো ট্যাগ push করলে APK স্বয়ংক্রিয়ভাবে GitHub Release-এ যুক্ত হবে।

## স্থায়ী সাইনিং (আপডেট ইনস্টলের জন্য, ঐচ্ছিক কিন্তু প্রস্তাবিত)
Repository Settings → Secrets and variables → Actions-এ যোগ করুন:
`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`।
কীস্টোর তৈরি: `keytool -genkeypair -v -keystore release.jks -alias nahid -keyalg RSA -keysize 2048 -validity 10000`
তারপর `base64 -w0 release.jks` এর ফলাফল `KEYSTORE_BASE64` এ দিন।

## Firebase
ডিফল্টভাবে অ্যাপ `dokan-c7c1e` প্রজেক্টের কনফিগ কোড থেকেই চালু হয়। চাইলে Firebase Console-এ package `com.nahid.enterprise` দিয়ে Android অ্যাপ যোগ করে `google-services.json` ডাউনলোড করুন এবং `app/google-services.json` হিসেবে রাখুন (অথবা base64 করে `GOOGLE_SERVICES_JSON` secret এ দিন) — বিল্ড সেটি নিজে ব্যবহার করবে।
`firestore.rules` Firebase Console-এ Publish করা থাকতে হবে।

## ফাইল সেভ
সম্পূর্ণ হিসাব Save করলে বা PDF ডাউনলোড চাপলে `Download/Nahid Enterprise/` ফোল্ডারে রঙিন `.pdf` ফাইল সংরক্ষিত হয়। সংরক্ষণ শেষে নোটিফিকেশন আসে (ট্যাপ করলে PDF খোলে) এবং স্ক্রিনে ফোল্ডারের নাম ও "খুলুন" বাটন দেখায়। Android 13+ এ প্রথম Login-এর পর নোটিফিকেশনের অনুমতি চাওয়া হয়।

## লোডিং স্ক্রিন
Login, Account তৈরি, Password reset, Logout, হিসাব Save, দ্রব্য Save, হিসাব Delete, PDF ডাউনলোড ও Cloud Sync-এর সময় পুরো স্ক্রিনে লোডিং দেখায়; কাজ চলাকালীন বাটন চাপা যায় না।
